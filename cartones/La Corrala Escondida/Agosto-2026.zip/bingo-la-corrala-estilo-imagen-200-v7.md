# Cartones de Bingo Musical - La Corrala Escondida (grande)

**Configuración:** 15 canciones por cartón · 200 cartones únicos

---

## Cartón 1

1. Los Manolos - All my Lovin
2. Mano Negra - Mala Vida
3. The Refrescos - Aquí No Hay Playa
4. Blues Brothers - Everybody Needs Somebody To Love
5. Dos Gardenias - Dos Gardenias
6. Cue Dj - El Baile Del Serrucho
7. El Hormiguero - Marron
8. IZAL - La mujer de verde
9. Gente De Zona - La Gozadera
10. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
11. La Hungara - Achilipu
12. Gasolina - Daddy Yankee
13. Tequila - Salta
14. Proyecto Uno - El Tiburón
15. Flying free - Pont Aeri

---

## Cartón 2

1. Climax - Mesa Que Mas Aplauda
2. Rauw Alejandro - Todo de Ti
3. DON OMAR - DILE, CUENTALE (BATUCADA)
4. Eivissa - Oh La La La
5. Coyote Dax - No Rompas Mi Corazón
6. La Oreja de Van Gogh - Rosas
7. Don Omar - Danza Kuduro
8. El Simbolo - Levantando Las Manos
9. Camilo - Vida de Rico
10. Macaco - Ojala no te hubiera conocido nunca
11. Bad Bunny - Yo Perreo Sola
12. El Consorcio - El chacachá del tren
13. Sebastián Yatra - Tacones Rojos
14. David Bisbal y Aitana - Si Tú La Quieres
15. Isabel Aaiún - El Himno de Mi Peña

---

## Cartón 3

1. Nino Bravo - Libre
2. Katy Perry - Roar
3. Camela - Cuando zarpa el amor
4. La Fiesta - La canción del velero
5. SBS - Sigue Al Lider (Follow The Leader)
6. Seguridad social - Chiquilla
7. Chimbala - Feliz
8. Daddy Yankee - Limbo
9. ROSALÍA, J Balvin - Con Altura
10. Georgie Dann - La Barbacoa
11. ROSALÍA - DESPECHÁ
12. José Luis Perales - Un Velero Llamado Libertad
13. Sebastián Yatra - Tacones Rojos
14. David Civera - Que La Detengan
15. Vicco - Nochentera

---

## Cartón 4

1. ACDC - T.N.T
2. Hector y Tito ft. Don Omar - Baila morena
3. El Barrio - Quiéreme
4. Chocolate - Mayonesa
5. Lola Indigo - LA REINA
6. King Africa - Paquito el chocolatero
7. Proyecto Uno - El Tiburón
8. ROSÉ y Bruno Mars - APT.
9. Dos Gardenias - Dos Gardenias
10. KAROL G - Si Antes Te Hubiera Conocido
11. Myke Towers - LA FALDA
12. Los Del Río - Macarena
13. Baby Lores - La Mujer del Pelotero
14. Paulina Rubio - Y Yo Sigo Aqui
15. Alaska y Dinarama - A Quién Le Importa

---

## Cartón 5

1. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
2. Pitbull - El Taxi
3. Juan Magán - Bailando por Ahi
4. El Hormiguero - Marron
5. El chaval de la peca - Abanibi
6. Bad Bunny - Yo Perreo Sola
7. Climax - Mesa Que Mas Aplauda
8. El chombo - El gato volador
9. Zapato Veloz - Tractor Amarillo
10. El Consorcio - El chacachá del tren
11. Los Delincuentes - Nube de Pegatina
12. Las Ketchup - Aserejé
13. Raphael - Mi Gran noche
14. Seguridad social - Chiquilla
15. LOS LUNNIS - HASTA MAÑANA

---

## Cartón 6

1. Flying free - Pont Aeri
2. ACDC - T.N.T
3. Camilo - Vida de Rico
4. La Pegatina - MariCarmen
5. Los Rodriguez - Hace Calor
6. Joaquin Sabina - Y Nos Dieron las Diez (Video)
7. Zapato Veloz - Tractor Amarillo
8. Marta, Sebas, Guille y los demás (Amaral)
9. El canto del loco - Zapatillas
10. SHAKIRA - BZRP Music Sessions #53
11. Pereza - Princesas
12. Las Ketchup - Aserejé
13. Aitana - LAS BABYS
14. The Refrescos - Aquí No Hay Playa
15. DON OMAR - DILE, CUENTALE (BATUCADA)

---

## Cartón 7

1. Jarabe de Palo - Eso que tú me das
2. Alaska y Dinarama - A Quién Le Importa
3. CNCO - Reggaetón Lento (Bailemos)
4. Don Omar - Danza Kuduro
5. BM y Luck Ra - La Morocha
6. Rauw Alejandro - Todo de Ti
7. El canto del loco - Zapatillas
8. Los Manolos - All my Lovin
9. ROSALÍA, J Balvin - Con Altura
10. Estopa - La Raja De Tu Falda
11. Macaco - Ojala no te hubiera conocido nunca
12. SBS - Sigue Al Lider (Follow The Leader)
13. Los chicanos del sur - Beso a beso
14. Santa Fe - Esto Es Pa Ti
15. Isabel Aaiún - El Himno de Mi Peña

---

## Cartón 8

1. SHAKIRA - BZRP Music Sessions #53
2. Daddy Yankee Feat. Omega - Estrellita De Madrugada
3. El chaval de la peca - Abanibi
4. Santa Fe - Esto Es Pa Ti
5. Cali Flow Latino - Ras Tas Tas
6. BM y Luck Ra - La Morocha
7. Radio Futura - Escuela de Calor
8. María Isabel - Antes muerta que sencilla
9. CNCO - Reggaetón Lento (Bailemos)
10. Aitana - LAS BABYS
11. King Africa - Bomba
12. Baby Lores - La Mujer del Pelotero
13. Vicco - Nochentera
14. Katy Perry - Roar
15. David Civera - Que La Detengan

---

## Cartón 9

1. Melendi - Caminando por la Vida
2. Chimbala - Feliz
3. Pereza - Princesas
4. The Refrescos - Aquí No Hay Playa
5. La Oreja de Van Gogh - Rosas
6. Marta, Sebas, Guille y los demás (Amaral)
7. Mano Negra - Mala Vida
8. ROSÉ y Bruno Mars - APT.
9. King Africa - Paquito el chocolatero
10. Los Rodriguez - Hace Calor
11. LOS LUNNIS - HASTA MAÑANA
12. Los chicanos del sur - Beso a beso
13. La Hungara - Achilipu
14. David Bisbal y Aitana - Si Tú La Quieres
15. Juan Magán - Bailando por Ahi

---

## Cartón 10

1. Georgie Dann - La Barbacoa
2. Paulina Rubio - Y Yo Sigo Aqui
3. Raphael - Mi Gran noche
4. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
5. Mambo No. 5 (A Little Bit of...)
6. Eivissa - Oh La La La
7. Jarabe de Palo - Eso que tú me das
8. Hector y Tito ft. Don Omar - Baila morena
9. ROSÉ y Bruno Mars - APT.
10. Tequila - Salta
11. Pereza - Princesas
12. Blues Brothers - Everybody Needs Somebody To Love
13. El Simbolo - Levantando Las Manos
14. IZAL - La mujer de verde
15. Alaska y Dinarama - A Quién Le Importa

---

## Cartón 11

1. KAROL G - Si Antes Te Hubiera Conocido
2. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
3. King Africa - Bomba
4. La Fiesta - La canción del velero
5. Chimbala - Feliz
6. Lola Indigo - LA REINA
7. BM y Luck Ra - La Morocha
8. Cue Dj - El Baile Del Serrucho
9. Chocolate - Mayonesa
10. David Civera - Que La Detengan
11. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
12. Nino Bravo - Libre
13. El chombo - El gato volador
14. José Luis Perales - Un Velero Llamado Libertad
15. King Africa - Paquito el chocolatero

---

## Cartón 12

1. Don Omar - Danza Kuduro
2. Pitbull - El Taxi
3. Gente De Zona - La Gozadera
4. Daddy Yankee Feat. Omega - Estrellita De Madrugada
5. Los Rodriguez - Hace Calor
6. Baby Lores - La Mujer del Pelotero
7. Nino Bravo - Libre
8. Carlinhos Brown and DJ Dero - Maria caipirinha
9. Camela - Cuando zarpa el amor
10. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
11. Melendi - Caminando por la Vida
12. El chaval de la peca - Abanibi
13. El chombo - El gato volador
14. Estopa - La Raja De Tu Falda
15. María Isabel - Antes muerta que sencilla

---

## Cartón 13

1. Mambo No. 5 (A Little Bit of...)
2. Chocolate - Mayonesa
3. Seguridad social - Chiquilla
4. Los Delincuentes - Nube de Pegatina
5. David Civera - Que La Detengan
6. El canto del loco - Zapatillas
7. Carlinhos Brown and DJ Dero - Maria caipirinha
8. Coyote Dax - No Rompas Mi Corazón
9. La Fiesta - La canción del velero
10. Katy Perry - Roar
11. Gasolina - Daddy Yankee
12. SHAKIRA - BZRP Music Sessions #53
13. Daddy Yankee Feat. Omega - Estrellita De Madrugada
14. Flying free - Pont Aeri
15. Cali Flow Latino - Ras Tas Tas

---

## Cartón 14

1. DON OMAR - DILE, CUENTALE (BATUCADA)
2. Hector y Tito ft. Don Omar - Baila morena
3. El Consorcio - El chacachá del tren
4. La Pegatina - MariCarmen
5. ROSALÍA - DESPECHÁ
6. Blues Brothers - Everybody Needs Somebody To Love
7. Los Del Río - Macarena
8. El Barrio - Quiéreme
9. SBS - Sigue Al Lider (Follow The Leader)
10. Jarabe de Palo - Eso que tú me das
11. King Africa - Paquito el chocolatero
12. Radio Futura - Escuela de Calor
13. Seguridad social - Chiquilla
14. Joaquin Sabina - Y Nos Dieron las Diez (Video)
15. Myke Towers - LA FALDA

---

## Cartón 15

1. King Africa - Bomba
2. La Oreja de Van Gogh - Rosas
3. Mano Negra - Mala Vida
4. Dos Gardenias - Dos Gardenias
5. Chocolate - Mayonesa
6. Bad Bunny - Yo Perreo Sola
7. Climax - Mesa Que Mas Aplauda
8. La Pegatina - MariCarmen
9. Daddy Yankee - Limbo
10. Carlinhos Brown and DJ Dero - Maria caipirinha
11. KAROL G - Si Antes Te Hubiera Conocido
12. Las Ketchup - Aserejé
13. IZAL - La mujer de verde
14. Los Delincuentes - Nube de Pegatina
15. ACDC - T.N.T

---

## Cartón 16

1. Los Del Río - Macarena
2. Radio Futura - Escuela de Calor
3. Aitana - LAS BABYS
4. The Refrescos - Aquí No Hay Playa
5. El Consorcio - El chacachá del tren
6. Raphael - Mi Gran noche
7. Gasolina - Daddy Yankee
8. El Hormiguero - Marron
9. Joaquin Sabina - Y Nos Dieron las Diez (Video)
10. Melendi - Caminando por la Vida
11. Coyote Dax - No Rompas Mi Corazón
12. Gente De Zona - La Gozadera
13. Myke Towers - LA FALDA
14. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
15. Los Rodriguez - Hace Calor

---

## Cartón 17

1. Flying free - Pont Aeri
2. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
3. Paulina Rubio - Y Yo Sigo Aqui
4. Raphael - Mi Gran noche
5. El chombo - El gato volador
6. El Barrio - Quiéreme
7. Juan Magán - Bailando por Ahi
8. La Oreja de Van Gogh - Rosas
9. La Fiesta - La canción del velero
10. Zapato Veloz - Tractor Amarillo
11. José Luis Perales - Un Velero Llamado Libertad
12. Isabel Aaiún - El Himno de Mi Peña
13. Eivissa - Oh La La La
14. Santa Fe - Esto Es Pa Ti
15. Proyecto Uno - El Tiburón

---

## Cartón 18

1. CNCO - Reggaetón Lento (Bailemos)
2. Cue Dj - El Baile Del Serrucho
3. Pitbull - El Taxi
4. ROSALÍA - DESPECHÁ
5. IZAL - La mujer de verde
6. Dos Gardenias - Dos Gardenias
7. María Isabel - Antes muerta que sencilla
8. David Bisbal y Aitana - Si Tú La Quieres
9. Isabel Aaiún - El Himno de Mi Peña
10. Lola Indigo - LA REINA
11. El Barrio - Quiéreme
12. Radio Futura - Escuela de Calor
13. Los chicanos del sur - Beso a beso
14. Marta, Sebas, Guille y los demás (Amaral)
15. Macaco - Ojala no te hubiera conocido nunca

---

## Cartón 19

1. SBS - Sigue Al Lider (Follow The Leader)
2. Blues Brothers - Everybody Needs Somebody To Love
3. Katy Perry - Roar
4. Mano Negra - Mala Vida
5. El Simbolo - Levantando Las Manos
6. Nino Bravo - Libre
7. Los Manolos - All my Lovin
8. Paulina Rubio - Y Yo Sigo Aqui
9. Daddy Yankee - Limbo
10. Las Ketchup - Aserejé
11. LOS LUNNIS - HASTA MAÑANA
12. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
13. Santa Fe - Esto Es Pa Ti
14. Georgie Dann - La Barbacoa
15. Cali Flow Latino - Ras Tas Tas

---

## Cartón 20

1. Joaquin Sabina - Y Nos Dieron las Diez (Video)
2. Camela - Cuando zarpa el amor
3. Myke Towers - LA FALDA
4. La Hungara - Achilipu
5. Camilo - Vida de Rico
6. KAROL G - Si Antes Te Hubiera Conocido
7. ROSALÍA, J Balvin - Con Altura
8. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
9. María Isabel - Antes muerta que sencilla
10. Carlinhos Brown and DJ Dero - Maria caipirinha
11. Aitana - LAS BABYS
12. King Africa - Bomba
13. Mambo No. 5 (A Little Bit of...)
14. Los Rodriguez - Hace Calor
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 21

1. Rauw Alejandro - Todo de Ti
2. Tequila - Salta
3. CNCO - Reggaetón Lento (Bailemos)
4. KAROL G - Si Antes Te Hubiera Conocido
5. Vicco - Nochentera
6. SBS - Sigue Al Lider (Follow The Leader)
7. ACDC - T.N.T
8. Hector y Tito ft. Don Omar - Baila morena
9. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
10. Climax - Mesa Que Mas Aplauda
11. ROSALÍA - DESPECHÁ
12. Aitana - LAS BABYS
13. La Hungara - Achilipu
14. Eivissa - Oh La La La
15. Estopa - La Raja De Tu Falda

---

## Cartón 22

1. Los Delincuentes - Nube de Pegatina
2. Daddy Yankee Feat. Omega - Estrellita De Madrugada
3. ROSÉ y Bruno Mars - APT.
4. Bad Bunny - Yo Perreo Sola
5. Chocolate - Mayonesa
6. Don Omar - Danza Kuduro
7. Cali Flow Latino - Ras Tas Tas
8. Pereza - Princesas
9. Camilo - Vida de Rico
10. Rauw Alejandro - Todo de Ti
11. La Fiesta - La canción del velero
12. LOS LUNNIS - HASTA MAÑANA
13. David Civera - Que La Detengan
14. El Simbolo - Levantando Las Manos
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 23

1. Rauw Alejandro - Todo de Ti
2. Seguridad social - Chiquilla
3. Los Manolos - All my Lovin
4. Zapato Veloz - Tractor Amarillo
5. Melendi - Caminando por la Vida
6. Jarabe de Palo - Eso que tú me das
7. The Refrescos - Aquí No Hay Playa
8. Cue Dj - El Baile Del Serrucho
9. Estopa - La Raja De Tu Falda
10. El Hormiguero - Marron
11. Pitbull - El Taxi
12. Tequila - Salta
13. Juan Magán - Bailando por Ahi
14. Cali Flow Latino - Ras Tas Tas
15. Los chicanos del sur - Beso a beso

---

## Cartón 24

1. Chimbala - Feliz
2. Camilo - Vida de Rico
3. Las Ketchup - Aserejé
4. El Hormiguero - Marron
5. Paulina Rubio - Y Yo Sigo Aqui
6. José Luis Perales - Un Velero Llamado Libertad
7. DON OMAR - DILE, CUENTALE (BATUCADA)
8. Alaska y Dinarama - A Quién Le Importa
9. BM y Luck Ra - La Morocha
10. Zapato Veloz - Tractor Amarillo
11. Georgie Dann - La Barbacoa
12. Vicco - Nochentera
13. ROSALÍA, J Balvin - Con Altura
14. Coyote Dax - No Rompas Mi Corazón
15. Proyecto Uno - El Tiburón

---

## Cartón 25

1. SHAKIRA - BZRP Music Sessions #53
2. Macaco - Ojala no te hubiera conocido nunca
3. ROSALÍA - DESPECHÁ
4. Joaquin Sabina - Y Nos Dieron las Diez (Video)
5. Proyecto Uno - El Tiburón
6. Daddy Yankee - Limbo
7. La Pegatina - MariCarmen
8. Gasolina - Daddy Yankee
9. Marta, Sebas, Guille y los demás (Amaral)
10. El canto del loco - Zapatillas
11. Katy Perry - Roar
12. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
13. Los Delincuentes - Nube de Pegatina
14. Don Omar - Danza Kuduro
15. Pereza - Princesas

---

## Cartón 26

1. DON OMAR - DILE, CUENTALE (BATUCADA)
2. Georgie Dann - La Barbacoa
3. Katy Perry - Roar
4. Los Del Río - Macarena
5. El chaval de la peca - Abanibi
6. Climax - Mesa Que Mas Aplauda
7. Marta, Sebas, Guille y los demás (Amaral)
8. Carlinhos Brown and DJ Dero - Maria caipirinha
9. ROSÉ y Bruno Mars - APT.
10. Daddy Yankee - Limbo
11. Camela - Cuando zarpa el amor
12. David Bisbal y Aitana - Si Tú La Quieres
13. María Isabel - Antes muerta que sencilla
14. Gente De Zona - La Gozadera
15. El Barrio - Quiéreme

---

## Cartón 27

1. Bad Bunny - Yo Perreo Sola
2. Baby Lores - La Mujer del Pelotero
3. CNCO - Reggaetón Lento (Bailemos)
4. BM y Luck Ra - La Morocha
5. Macaco - Ojala no te hubiera conocido nunca
6. La Hungara - Achilipu
7. Hector y Tito ft. Don Omar - Baila morena
8. Santa Fe - Esto Es Pa Ti
9. Vicco - Nochentera
10. Proyecto Uno - El Tiburón
11. Alaska y Dinarama - A Quién Le Importa
12. Gente De Zona - La Gozadera
13. José Luis Perales - Un Velero Llamado Libertad
14. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
15. Cue Dj - El Baile Del Serrucho

---

## Cartón 28

1. Radio Futura - Escuela de Calor
2. Gasolina - Daddy Yankee
3. David Civera - Que La Detengan
4. Pitbull - El Taxi
5. Los Manolos - All my Lovin
6. Baby Lores - La Mujer del Pelotero
7. Lola Indigo - LA REINA
8. La Hungara - Achilipu
9. Nino Bravo - Libre
10. LOS LUNNIS - HASTA MAÑANA
11. Chimbala - Feliz
12. Coyote Dax - No Rompas Mi Corazón
13. Los chicanos del sur - Beso a beso
14. Isabel Aaiún - El Himno de Mi Peña
15. Mano Negra - Mala Vida

---

## Cartón 29

1. Eivissa - Oh La La La
2. Los Del Río - Macarena
3. Dos Gardenias - Dos Gardenias
4. La Oreja de Van Gogh - Rosas
5. David Bisbal y Aitana - Si Tú La Quieres
6. Bad Bunny - Yo Perreo Sola
7. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
8. Climax - Mesa Que Mas Aplauda
9. SBS - Sigue Al Lider (Follow The Leader)
10. Pereza - Princesas
11. Coyote Dax - No Rompas Mi Corazón
12. El Consorcio - El chacachá del tren
13. Mambo No. 5 (A Little Bit of...)
14. El canto del loco - Zapatillas
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 30

1. IZAL - La mujer de verde
2. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
3. Radio Futura - Escuela de Calor
4. El chaval de la peca - Abanibi
5. Vicco - Nochentera
6. Los Del Río - Macarena
7. El Simbolo - Levantando Las Manos
8. Georgie Dann - La Barbacoa
9. Mano Negra - Mala Vida
10. Lola Indigo - LA REINA
11. CNCO - Reggaetón Lento (Bailemos)
12. La Pegatina - MariCarmen
13. Daddy Yankee Feat. Omega - Estrellita De Madrugada
14. Dos Gardenias - Dos Gardenias
15. El chombo - El gato volador

---

## Cartón 31

1. El Barrio - Quiéreme
2. Flying free - Pont Aeri
3. King Africa - Bomba
4. Santa Fe - Esto Es Pa Ti
5. KAROL G - Si Antes Te Hubiera Conocido
6. Macaco - Ojala no te hubiera conocido nunca
7. Rauw Alejandro - Todo de Ti
8. Estopa - La Raja De Tu Falda
9. Jarabe de Palo - Eso que tú me das
10. Blues Brothers - Everybody Needs Somebody To Love
11. Juan Magán - Bailando por Ahi
12. Melendi - Caminando por la Vida
13. El Simbolo - Levantando Las Manos
14. BM y Luck Ra - La Morocha
15. La Fiesta - La canción del velero

---

## Cartón 32

1. Radio Futura - Escuela de Calor
2. Camela - Cuando zarpa el amor
3. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
4. La Oreja de Van Gogh - Rosas
5. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
6. Tequila - Salta
7. Carlinhos Brown and DJ Dero - Maria caipirinha
8. ROSALÍA, J Balvin - Con Altura
9. Zapato Veloz - Tractor Amarillo
10. Daddy Yankee - Limbo
11. SHAKIRA - BZRP Music Sessions #53
12. Raphael - Mi Gran noche
13. ACDC - T.N.T
14. Eivissa - Oh La La La
15. Los chicanos del sur - Beso a beso

---

## Cartón 33

1. Baby Lores - La Mujer del Pelotero
2. El canto del loco - Zapatillas
3. El Hormiguero - Marron
4. Gasolina - Daddy Yankee
5. Cali Flow Latino - Ras Tas Tas
6. The Refrescos - Aquí No Hay Playa
7. LOS LUNNIS - HASTA MAÑANA
8. Climax - Mesa Que Mas Aplauda
9. Mambo No. 5 (A Little Bit of...)
10. ROSALÍA, J Balvin - Con Altura
11. Lola Indigo - LA REINA
12. ACDC - T.N.T
13. Gente De Zona - La Gozadera
14. King Africa - Paquito el chocolatero
15. Juan Magán - Bailando por Ahi

---

## Cartón 34

1. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
2. DON OMAR - DILE, CUENTALE (BATUCADA)
3. Pitbull - El Taxi
4. Daddy Yankee Feat. Omega - Estrellita De Madrugada
5. Sebastián Yatra - Tacones Rojos
6. Isabel Aaiún - El Himno de Mi Peña
7. SHAKIRA - BZRP Music Sessions #53
8. Camela - Cuando zarpa el amor
9. Chimbala - Feliz
10. Joaquin Sabina - Y Nos Dieron las Diez (Video)
11. ROSALÍA - DESPECHÁ
12. Flying free - Pont Aeri
13. Las Ketchup - Aserejé
14. Tequila - Salta
15. Blues Brothers - Everybody Needs Somebody To Love

---

## Cartón 35

1. David Civera - Que La Detengan
2. Estopa - La Raja De Tu Falda
3. Los Delincuentes - Nube de Pegatina
4. Jarabe de Palo - Eso que tú me das
5. Marta, Sebas, Guille y los demás (Amaral)
6. Myke Towers - LA FALDA
7. Aitana - LAS BABYS
8. DON OMAR - DILE, CUENTALE (BATUCADA)
9. Gente De Zona - La Gozadera
10. Don Omar - Danza Kuduro
11. Pereza - Princesas
12. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
13. Hector y Tito ft. Don Omar - Baila morena
14. La Pegatina - MariCarmen
15. El Barrio - Quiéreme

---

## Cartón 36

1. Melendi - Caminando por la Vida
2. Gasolina - Daddy Yankee
3. La Fiesta - La canción del velero
4. King Africa - Paquito el chocolatero
5. El chaval de la peca - Abanibi
6. KAROL G - Si Antes Te Hubiera Conocido
7. IZAL - La mujer de verde
8. David Bisbal y Aitana - Si Tú La Quieres
9. Cue Dj - El Baile Del Serrucho
10. Myke Towers - LA FALDA
11. Cali Flow Latino - Ras Tas Tas
12. El Hormiguero - Marron
13. Raphael - Mi Gran noche
14. Juan Magán - Bailando por Ahi
15. Seguridad social - Chiquilla

---

## Cartón 37

1. Raphael - Mi Gran noche
2. El chombo - El gato volador
3. José Luis Perales - Un Velero Llamado Libertad
4. Camilo - Vida de Rico
5. El Consorcio - El chacachá del tren
6. Los Rodriguez - Hace Calor
7. Los Delincuentes - Nube de Pegatina
8. Flying free - Pont Aeri
9. Chocolate - Mayonesa
10. Jarabe de Palo - Eso que tú me das
11. Las Ketchup - Aserejé
12. Cue Dj - El Baile Del Serrucho
13. Carlinhos Brown and DJ Dero - Maria caipirinha
14. CNCO - Reggaetón Lento (Bailemos)
15. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer

---

## Cartón 38

1. María Isabel - Antes muerta que sencilla
2. El Consorcio - El chacachá del tren
3. Nino Bravo - Libre
4. El chombo - El gato volador
5. La Pegatina - MariCarmen
6. Los chicanos del sur - Beso a beso
7. Pitbull - El Taxi
8. Aitana - LAS BABYS
9. Dos Gardenias - Dos Gardenias
10. Los Manolos - All my Lovin
11. SBS - Sigue Al Lider (Follow The Leader)
12. Camilo - Vida de Rico
13. Coyote Dax - No Rompas Mi Corazón
14. Paulina Rubio - Y Yo Sigo Aqui
15. ROSALÍA, J Balvin - Con Altura

---

## Cartón 39

1. ROSÉ y Bruno Mars - APT.
2. La Fiesta - La canción del velero
3. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
4. Melendi - Caminando por la Vida
5. Isabel Aaiún - El Himno de Mi Peña
6. Proyecto Uno - El Tiburón
7. Blues Brothers - Everybody Needs Somebody To Love
8. Alaska y Dinarama - A Quién Le Importa
9. King Africa - Bomba
10. Estopa - La Raja De Tu Falda
11. El chaval de la peca - Abanibi
12. José Luis Perales - Un Velero Llamado Libertad
13. Don Omar - Danza Kuduro
14. María Isabel - Antes muerta que sencilla
15. El Simbolo - Levantando Las Manos

---

## Cartón 40

1. Chocolate - Mayonesa
2. ROSALÍA - DESPECHÁ
3. Daddy Yankee Feat. Omega - Estrellita De Madrugada
4. Isabel Aaiún - El Himno de Mi Peña
5. Marta, Sebas, Guille y los demás (Amaral)
6. Alaska y Dinarama - A Quién Le Importa
7. Myke Towers - LA FALDA
8. IZAL - La mujer de verde
9. Rauw Alejandro - Todo de Ti
10. Hector y Tito ft. Don Omar - Baila morena
11. ACDC - T.N.T
12. Santa Fe - Esto Es Pa Ti
13. Joaquin Sabina - Y Nos Dieron las Diez (Video)
14. SBS - Sigue Al Lider (Follow The Leader)
15. Los Del Río - Macarena

---

## Cartón 41

1. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
2. El chombo - El gato volador
3. Seguridad social - Chiquilla
4. Zapato Veloz - Tractor Amarillo
5. LOS LUNNIS - HASTA MAÑANA
6. La Oreja de Van Gogh - Rosas
7. Baby Lores - La Mujer del Pelotero
8. Cue Dj - El Baile Del Serrucho
9. BM y Luck Ra - La Morocha
10. ROSÉ y Bruno Mars - APT.
11. Aitana - LAS BABYS
12. Mambo No. 5 (A Little Bit of...)
13. Los Rodriguez - Hace Calor
14. Camela - Cuando zarpa el amor
15. Bad Bunny - Yo Perreo Sola

---

## Cartón 42

1. La Hungara - Achilipu
2. Los Manolos - All my Lovin
3. King Africa - Paquito el chocolatero
4. Los Delincuentes - Nube de Pegatina
5. Macaco - Ojala no te hubiera conocido nunca
6. ROSÉ y Bruno Mars - APT.
7. El Consorcio - El chacachá del tren
8. Camilo - Vida de Rico
9. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
10. Mano Negra - Mala Vida
11. ROSALÍA - DESPECHÁ
12. SHAKIRA - BZRP Music Sessions #53
13. José Luis Perales - Un Velero Llamado Libertad
14. Radio Futura - Escuela de Calor
15. Vicco - Nochentera

---

## Cartón 43

1. Katy Perry - Roar
2. Joaquin Sabina - Y Nos Dieron las Diez (Video)
3. Santa Fe - Esto Es Pa Ti
4. Sebastián Yatra - Tacones Rojos
5. Georgie Dann - La Barbacoa
6. Los Del Río - Macarena
7. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
8. Flying free - Pont Aeri
9. King Africa - Bomba
10. Melendi - Caminando por la Vida
11. DON OMAR - DILE, CUENTALE (BATUCADA)
12. Pereza - Princesas
13. Daddy Yankee - Limbo
14. Mambo No. 5 (A Little Bit of...)
15. Hector y Tito ft. Don Omar - Baila morena

---

## Cartón 44

1. La Oreja de Van Gogh - Rosas
2. El Hormiguero - Marron
3. The Refrescos - Aquí No Hay Playa
4. Pitbull - El Taxi
5. La Hungara - Achilipu
6. Las Ketchup - Aserejé
7. Raphael - Mi Gran noche
8. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
9. El canto del loco - Zapatillas
10. Tequila - Salta
11. Seguridad social - Chiquilla
12. Paulina Rubio - Y Yo Sigo Aqui
13. La Pegatina - MariCarmen
14. Los chicanos del sur - Beso a beso
15. Nino Bravo - Libre

---

## Cartón 45

1. Isabel Aaiún - El Himno de Mi Peña
2. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
3. Lola Indigo - LA REINA
4. El Simbolo - Levantando Las Manos
5. Cali Flow Latino - Ras Tas Tas
6. Katy Perry - Roar
7. Cue Dj - El Baile Del Serrucho
8. Blues Brothers - Everybody Needs Somebody To Love
9. IZAL - La mujer de verde
10. CNCO - Reggaetón Lento (Bailemos)
11. David Bisbal y Aitana - Si Tú La Quieres
12. Eivissa - Oh La La La
13. Chimbala - Feliz
14. Don Omar - Danza Kuduro
15. Juan Magán - Bailando por Ahi

---

## Cartón 46

1. ACDC - T.N.T
2. SHAKIRA - BZRP Music Sessions #53
3. LOS LUNNIS - HASTA MAÑANA
4. David Bisbal y Aitana - Si Tú La Quieres
5. ROSALÍA, J Balvin - Con Altura
6. King Africa - Paquito el chocolatero
7. Lola Indigo - LA REINA
8. Bad Bunny - Yo Perreo Sola
9. Pitbull - El Taxi
10. Daddy Yankee - Limbo
11. Alaska y Dinarama - A Quién Le Importa
12. Blues Brothers - Everybody Needs Somebody To Love
13. Proyecto Uno - El Tiburón
14. Camela - Cuando zarpa el amor
15. Pereza - Princesas

---

## Cartón 47

1. Daddy Yankee Feat. Omega - Estrellita De Madrugada
2. Dos Gardenias - Dos Gardenias
3. Aitana - LAS BABYS
4. Marta, Sebas, Guille y los demás (Amaral)
5. Gasolina - Daddy Yankee
6. El canto del loco - Zapatillas
7. Sebastián Yatra - Tacones Rojos
8. Flying free - Pont Aeri
9. Vicco - Nochentera
10. Chocolate - Mayonesa
11. KAROL G - Si Antes Te Hubiera Conocido
12. Los Rodriguez - Hace Calor
13. Santa Fe - Esto Es Pa Ti
14. IZAL - La mujer de verde
15. BM y Luck Ra - La Morocha

---

## Cartón 48

1. Nino Bravo - Libre
2. Gasolina - Daddy Yankee
3. Los chicanos del sur - Beso a beso
4. David Civera - Que La Detengan
5. José Luis Perales - Un Velero Llamado Libertad
6. King Africa - Paquito el chocolatero
7. Jarabe de Palo - Eso que tú me das
8. Myke Towers - LA FALDA
9. Camela - Cuando zarpa el amor
10. Sebastián Yatra - Tacones Rojos
11. Mambo No. 5 (A Little Bit of...)
12. Tequila - Salta
13. ROSÉ y Bruno Mars - APT.
14. María Isabel - Antes muerta que sencilla
15. El chaval de la peca - Abanibi

---

## Cartón 49

1. Juan Magán - Bailando por Ahi
2. Climax - Mesa Que Mas Aplauda
3. The Refrescos - Aquí No Hay Playa
4. La Pegatina - MariCarmen
5. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
6. Macaco - Ojala no te hubiera conocido nunca
7. Dos Gardenias - Dos Gardenias
8. ROSALÍA - DESPECHÁ
9. ROSALÍA, J Balvin - Con Altura
10. El chaval de la peca - Abanibi
11. Estopa - La Raja De Tu Falda
12. Eivissa - Oh La La La
13. Paulina Rubio - Y Yo Sigo Aqui
14. Los Del Río - Macarena
15. Rauw Alejandro - Todo de Ti

---

## Cartón 50

1. El canto del loco - Zapatillas
2. Macaco - Ojala no te hubiera conocido nunca
3. Katy Perry - Roar
4. Raphael - Mi Gran noche
5. Chimbala - Feliz
6. ACDC - T.N.T
7. BM y Luck Ra - La Morocha
8. Alaska y Dinarama - A Quién Le Importa
9. Paulina Rubio - Y Yo Sigo Aqui
10. Georgie Dann - La Barbacoa
11. Carlinhos Brown and DJ Dero - Maria caipirinha
12. Hector y Tito ft. Don Omar - Baila morena
13. Eivissa - Oh La La La
14. Gente De Zona - La Gozadera
15. LOS LUNNIS - HASTA MAÑANA

---

## Cartón 51

1. Radio Futura - Escuela de Calor
2. Coyote Dax - No Rompas Mi Corazón
3. La Oreja de Van Gogh - Rosas
4. Zapato Veloz - Tractor Amarillo
5. La Fiesta - La canción del velero
6. Georgie Dann - La Barbacoa
7. SBS - Sigue Al Lider (Follow The Leader)
8. Lola Indigo - LA REINA
9. Alaska y Dinarama - A Quién Le Importa
10. Mambo No. 5 (A Little Bit of...)
11. María Isabel - Antes muerta que sencilla
12. El Consorcio - El chacachá del tren
13. Los Manolos - All my Lovin
14. El Hormiguero - Marron
15. Baby Lores - La Mujer del Pelotero

---

## Cartón 52

1. María Isabel - Antes muerta que sencilla
2. Marta, Sebas, Guille y los demás (Amaral)
3. Chimbala - Feliz
4. Radio Futura - Escuela de Calor
5. Myke Towers - LA FALDA
6. El Barrio - Quiéreme
7. Dos Gardenias - Dos Gardenias
8. La Hungara - Achilipu
9. Aitana - LAS BABYS
10. Proyecto Uno - El Tiburón
11. King Africa - Bomba
12. Zapato Veloz - Tractor Amarillo
13. Los Rodriguez - Hace Calor
14. Macaco - Ojala no te hubiera conocido nunca
15. Mano Negra - Mala Vida

---

## Cartón 53

1. Baby Lores - La Mujer del Pelotero
2. Seguridad social - Chiquilla
3. SHAKIRA - BZRP Music Sessions #53
4. Melendi - Caminando por la Vida
5. Vicco - Nochentera
6. The Refrescos - Aquí No Hay Playa
7. Zapato Veloz - Tractor Amarillo
8. Hector y Tito ft. Don Omar - Baila morena
9. Joaquin Sabina - Y Nos Dieron las Diez (Video)
10. Chimbala - Feliz
11. Cali Flow Latino - Ras Tas Tas
12. Don Omar - Danza Kuduro
13. Carlinhos Brown and DJ Dero - Maria caipirinha
14. SBS - Sigue Al Lider (Follow The Leader)
15. Los Manolos - All my Lovin

---

## Cartón 54

1. Joaquin Sabina - Y Nos Dieron las Diez (Video)
2. Climax - Mesa Que Mas Aplauda
3. Santa Fe - Esto Es Pa Ti
4. Gasolina - Daddy Yankee
5. Marta, Sebas, Guille y los demás (Amaral)
6. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
7. Nino Bravo - Libre
8. Camilo - Vida de Rico
9. Mano Negra - Mala Vida
10. El chombo - El gato volador
11. Rauw Alejandro - Todo de Ti
12. Daddy Yankee - Limbo
13. La Oreja de Van Gogh - Rosas
14. Los Del Río - Macarena
15. Los Rodriguez - Hace Calor

---

## Cartón 55

1. Don Omar - Danza Kuduro
2. Coyote Dax - No Rompas Mi Corazón
3. Estopa - La Raja De Tu Falda
4. CNCO - Reggaetón Lento (Bailemos)
5. Blues Brothers - Everybody Needs Somebody To Love
6. Jarabe de Palo - Eso que tú me das
7. Seguridad social - Chiquilla
8. King Africa - Bomba
9. ACDC - T.N.T
10. Camela - Cuando zarpa el amor
11. Baby Lores - La Mujer del Pelotero
12. ROSALÍA - DESPECHÁ
13. LOS LUNNIS - HASTA MAÑANA
14. David Bisbal y Aitana - Si Tú La Quieres
15. Los chicanos del sur - Beso a beso

---

## Cartón 56

1. CNCO - Reggaetón Lento (Bailemos)
2. Camilo - Vida de Rico
3. Los Delincuentes - Nube de Pegatina
4. David Civera - Que La Detengan
5. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
6. The Refrescos - Aquí No Hay Playa
7. Georgie Dann - La Barbacoa
8. María Isabel - Antes muerta que sencilla
9. Daddy Yankee Feat. Omega - Estrellita De Madrugada
10. El Barrio - Quiéreme
11. Jarabe de Palo - Eso que tú me das
12. ROSALÍA - DESPECHÁ
13. José Luis Perales - Un Velero Llamado Libertad
14. DON OMAR - DILE, CUENTALE (BATUCADA)
15. Gente De Zona - La Gozadera

---

## Cartón 57

1. Mambo No. 5 (A Little Bit of...)
2. Flying free - Pont Aeri
3. KAROL G - Si Antes Te Hubiera Conocido
4. El Barrio - Quiéreme
5. Tequila - Salta
6. La Pegatina - MariCarmen
7. La Hungara - Achilipu
8. Cali Flow Latino - Ras Tas Tas
9. Daddy Yankee Feat. Omega - Estrellita De Madrugada
10. El canto del loco - Zapatillas
11. Climax - Mesa Que Mas Aplauda
12. El Simbolo - Levantando Las Manos
13. Baby Lores - La Mujer del Pelotero
14. Coyote Dax - No Rompas Mi Corazón
15. BM y Luck Ra - La Morocha

---

## Cartón 58

1. Hector y Tito ft. Don Omar - Baila morena
2. Las Ketchup - Aserejé
3. Carlinhos Brown and DJ Dero - Maria caipirinha
4. Los Manolos - All my Lovin
5. Cue Dj - El Baile Del Serrucho
6. Paulina Rubio - Y Yo Sigo Aqui
7. Estopa - La Raja De Tu Falda
8. KAROL G - Si Antes Te Hubiera Conocido
9. King Africa - Bomba
10. Jarabe de Palo - Eso que tú me das
11. Pitbull - El Taxi
12. Pereza - Princesas
13. Chocolate - Mayonesa
14. Lola Indigo - LA REINA
15. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom

---

## Cartón 59

1. CNCO - Reggaetón Lento (Bailemos)
2. ROSALÍA, J Balvin - Con Altura
3. David Bisbal y Aitana - Si Tú La Quieres
4. Los Manolos - All my Lovin
5. IZAL - La mujer de verde
6. Sebastián Yatra - Tacones Rojos
7. Paulina Rubio - Y Yo Sigo Aqui
8. Myke Towers - LA FALDA
9. Bad Bunny - Yo Perreo Sola
10. El Consorcio - El chacachá del tren
11. David Civera - Que La Detengan
12. King Africa - Paquito el chocolatero
13. Carlinhos Brown and DJ Dero - Maria caipirinha
14. El Simbolo - Levantando Las Manos
15. Mambo No. 5 (A Little Bit of...)

---

## Cartón 60

1. Proyecto Uno - El Tiburón
2. Myke Towers - LA FALDA
3. Bad Bunny - Yo Perreo Sola
4. Nino Bravo - Libre
5. Rauw Alejandro - Todo de Ti
6. Melendi - Caminando por la Vida
7. Estopa - La Raja De Tu Falda
8. CNCO - Reggaetón Lento (Bailemos)
9. ROSÉ y Bruno Mars - APT.
10. KAROL G - Si Antes Te Hubiera Conocido
11. Vicco - Nochentera
12. Cue Dj - El Baile Del Serrucho
13. Chocolate - Mayonesa
14. El chombo - El gato volador
15. Los Delincuentes - Nube de Pegatina

---

## Cartón 61

1. SHAKIRA - BZRP Music Sessions #53
2. DON OMAR - DILE, CUENTALE (BATUCADA)
3. Daddy Yankee - Limbo
4. El chaval de la peca - Abanibi
5. Zapato Veloz - Tractor Amarillo
6. Los Rodriguez - Hace Calor
7. Radio Futura - Escuela de Calor
8. Camilo - Vida de Rico
9. Alaska y Dinarama - A Quién Le Importa
10. Rauw Alejandro - Todo de Ti
11. Lola Indigo - LA REINA
12. El Hormiguero - Marron
13. ACDC - T.N.T
14. Mano Negra - Mala Vida
15. La Oreja de Van Gogh - Rosas

---

## Cartón 62

1. BM y Luck Ra - La Morocha
2. Los Del Río - Macarena
3. Los Delincuentes - Nube de Pegatina
4. King Africa - Paquito el chocolatero
5. DON OMAR - DILE, CUENTALE (BATUCADA)
6. El Simbolo - Levantando Las Manos
7. ROSÉ y Bruno Mars - APT.
8. Melendi - Caminando por la Vida
9. Blues Brothers - Everybody Needs Somebody To Love
10. Aitana - LAS BABYS
11. Isabel Aaiún - El Himno de Mi Peña
12. Las Ketchup - Aserejé
13. Raphael - Mi Gran noche
14. El chombo - El gato volador
15. Marta, Sebas, Guille y los demás (Amaral)

---

## Cartón 63

1. Camilo - Vida de Rico
2. Blues Brothers - Everybody Needs Somebody To Love
3. El Consorcio - El chacachá del tren
4. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
5. Estopa - La Raja De Tu Falda
6. LOS LUNNIS - HASTA MAÑANA
7. IZAL - La mujer de verde
8. Juan Magán - Bailando por Ahi
9. Nino Bravo - Libre
10. SHAKIRA - BZRP Music Sessions #53
11. La Fiesta - La canción del velero
12. ROSALÍA, J Balvin - Con Altura
13. Melendi - Caminando por la Vida
14. Katy Perry - Roar
15. Tequila - Salta

---

## Cartón 64

1. Eivissa - Oh La La La
2. Juan Magán - Bailando por Ahi
3. El Barrio - Quiéreme
4. José Luis Perales - Un Velero Llamado Libertad
5. Los Rodriguez - Hace Calor
6. Proyecto Uno - El Tiburón
7. Tequila - Salta
8. King Africa - Bomba
9. Vicco - Nochentera
10. Raphael - Mi Gran noche
11. Coyote Dax - No Rompas Mi Corazón
12. Gente De Zona - La Gozadera
13. Camela - Cuando zarpa el amor
14. Macaco - Ojala no te hubiera conocido nunca
15. Nino Bravo - Libre

---

## Cartón 65

1. La Fiesta - La canción del velero
2. Las Ketchup - Aserejé
3. Marta, Sebas, Guille y los demás (Amaral)
4. Dos Gardenias - Dos Gardenias
5. ROSALÍA, J Balvin - Con Altura
6. Alaska y Dinarama - A Quién Le Importa
7. Cali Flow Latino - Ras Tas Tas
8. SBS - Sigue Al Lider (Follow The Leader)
9. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
10. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
11. La Hungara - Achilipu
12. Los chicanos del sur - Beso a beso
13. Flying free - Pont Aeri
14. El chaval de la peca - Abanibi
15. Katy Perry - Roar

---

## Cartón 66

1. Pereza - Princesas
2. Santa Fe - Esto Es Pa Ti
3. BM y Luck Ra - La Morocha
4. Daddy Yankee - Limbo
5. Seguridad social - Chiquilla
6. El canto del loco - Zapatillas
7. Mano Negra - Mala Vida
8. Climax - Mesa Que Mas Aplauda
9. Chocolate - Mayonesa
10. DON OMAR - DILE, CUENTALE (BATUCADA)
11. Eivissa - Oh La La La
12. Las Ketchup - Aserejé
13. Cali Flow Latino - Ras Tas Tas
14. Paulina Rubio - Y Yo Sigo Aqui
15. La Hungara - Achilipu

---

## Cartón 67

1. ROSALÍA - DESPECHÁ
2. King Africa - Bomba
3. Juan Magán - Bailando por Ahi
4. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
5. Raphael - Mi Gran noche
6. Chocolate - Mayonesa
7. El Hormiguero - Marron
8. Gasolina - Daddy Yankee
9. La Pegatina - MariCarmen
10. The Refrescos - Aquí No Hay Playa
11. El chombo - El gato volador
12. Camela - Cuando zarpa el amor
13. Sebastián Yatra - Tacones Rojos
14. ROSÉ y Bruno Mars - APT.
15. Radio Futura - Escuela de Calor

---

## Cartón 68

1. Tequila - Salta
2. Pereza - Princesas
3. KAROL G - Si Antes Te Hubiera Conocido
4. Aitana - LAS BABYS
5. Katy Perry - Roar
6. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
7. Macaco - Ojala no te hubiera conocido nunca
8. David Civera - Que La Detengan
9. Pitbull - El Taxi
10. El canto del loco - Zapatillas
11. José Luis Perales - Un Velero Llamado Libertad
12. Jarabe de Palo - Eso que tú me das
13. Carlinhos Brown and DJ Dero - Maria caipirinha
14. Chimbala - Feliz
15. Gente De Zona - La Gozadera

---

## Cartón 69

1. El canto del loco - Zapatillas
2. David Bisbal y Aitana - Si Tú La Quieres
3. Daddy Yankee Feat. Omega - Estrellita De Madrugada
4. King Africa - Paquito el chocolatero
5. Georgie Dann - La Barbacoa
6. Santa Fe - Esto Es Pa Ti
7. Melendi - Caminando por la Vida
8. Eivissa - Oh La La La
9. ACDC - T.N.T
10. El Hormiguero - Marron
11. Joaquin Sabina - Y Nos Dieron las Diez (Video)
12. LOS LUNNIS - HASTA MAÑANA
13. Los Manolos - All my Lovin
14. SBS - Sigue Al Lider (Follow The Leader)
15. El Simbolo - Levantando Las Manos

---

## Cartón 70

1. Mano Negra - Mala Vida
2. Los chicanos del sur - Beso a beso
3. Coyote Dax - No Rompas Mi Corazón
4. Pitbull - El Taxi
5. Isabel Aaiún - El Himno de Mi Peña
6. CNCO - Reggaetón Lento (Bailemos)
7. Juan Magán - Bailando por Ahi
8. Seguridad social - Chiquilla
9. KAROL G - Si Antes Te Hubiera Conocido
10. ROSALÍA, J Balvin - Con Altura
11. Los Del Río - Macarena
12. Lola Indigo - LA REINA
13. Don Omar - Danza Kuduro
14. Bad Bunny - Yo Perreo Sola
15. The Refrescos - Aquí No Hay Playa

---

## Cartón 71

1. Paulina Rubio - Y Yo Sigo Aqui
2. Cue Dj - El Baile Del Serrucho
3. SHAKIRA - BZRP Music Sessions #53
4. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
5. Flying free - Pont Aeri
6. Mambo No. 5 (A Little Bit of...)
7. Bad Bunny - Yo Perreo Sola
8. SBS - Sigue Al Lider (Follow The Leader)
9. Los Manolos - All my Lovin
10. Chimbala - Feliz
11. David Bisbal y Aitana - Si Tú La Quieres
12. Don Omar - Danza Kuduro
13. Gente De Zona - La Gozadera
14. Camilo - Vida de Rico
15. Nino Bravo - Libre

---

## Cartón 72

1. Los Delincuentes - Nube de Pegatina
2. Seguridad social - Chiquilla
3. Aitana - LAS BABYS
4. SHAKIRA - BZRP Music Sessions #53
5. David Civera - Que La Detengan
6. Climax - Mesa Que Mas Aplauda
7. Vicco - Nochentera
8. Camela - Cuando zarpa el amor
9. Los chicanos del sur - Beso a beso
10. El Barrio - Quiéreme
11. Sebastián Yatra - Tacones Rojos
12. La Oreja de Van Gogh - Rosas
13. Myke Towers - LA FALDA
14. Baby Lores - La Mujer del Pelotero
15. Gasolina - Daddy Yankee

---

## Cartón 73

1. El chaval de la peca - Abanibi
2. ROSÉ y Bruno Mars - APT.
3. Hector y Tito ft. Don Omar - Baila morena
4. Las Ketchup - Aserejé
5. La Fiesta - La canción del velero
6. Isabel Aaiún - El Himno de Mi Peña
7. Coyote Dax - No Rompas Mi Corazón
8. Don Omar - Danza Kuduro
9. Pereza - Princesas
10. Sebastián Yatra - Tacones Rojos
11. Tequila - Salta
12. Katy Perry - Roar
13. Rauw Alejandro - Todo de Ti
14. Georgie Dann - La Barbacoa
15. El Consorcio - El chacachá del tren

---

## Cartón 74

1. Eivissa - Oh La La La
2. Vicco - Nochentera
3. Cali Flow Latino - Ras Tas Tas
4. Proyecto Uno - El Tiburón
5. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
6. Cue Dj - El Baile Del Serrucho
7. La Pegatina - MariCarmen
8. Hector y Tito ft. Don Omar - Baila morena
9. David Civera - Que La Detengan
10. El Simbolo - Levantando Las Manos
11. DON OMAR - DILE, CUENTALE (BATUCADA)
12. Los Del Río - Macarena
13. Jarabe de Palo - Eso que tú me das
14. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
15. Los Delincuentes - Nube de Pegatina

---

## Cartón 75

1. Rauw Alejandro - Todo de Ti
2. Don Omar - Danza Kuduro
3. Dos Gardenias - Dos Gardenias
4. Camela - Cuando zarpa el amor
5. Marta, Sebas, Guille y los demás (Amaral)
6. El chombo - El gato volador
7. María Isabel - Antes muerta que sencilla
8. Baby Lores - La Mujer del Pelotero
9. Cali Flow Latino - Ras Tas Tas
10. Mambo No. 5 (A Little Bit of...)
11. Zapato Veloz - Tractor Amarillo
12. Daddy Yankee Feat. Omega - Estrellita De Madrugada
13. El Consorcio - El chacachá del tren
14. La Oreja de Van Gogh - Rosas
15. Joaquin Sabina - Y Nos Dieron las Diez (Video)

---

## Cartón 76

1. BM y Luck Ra - La Morocha
2. Georgie Dann - La Barbacoa
3. King Africa - Paquito el chocolatero
4. Estopa - La Raja De Tu Falda
5. José Luis Perales - Un Velero Llamado Libertad
6. Gasolina - Daddy Yankee
7. Joaquin Sabina - Y Nos Dieron las Diez (Video)
8. Los Rodriguez - Hace Calor
9. Daddy Yankee - Limbo
10. David Bisbal y Aitana - Si Tú La Quieres
11. Raphael - Mi Gran noche
12. Lola Indigo - LA REINA
13. Chocolate - Mayonesa
14. Climax - Mesa Que Mas Aplauda
15. SBS - Sigue Al Lider (Follow The Leader)

---

## Cartón 77

1. La Oreja de Van Gogh - Rosas
2. Daddy Yankee Feat. Omega - Estrellita De Madrugada
3. Mambo No. 5 (A Little Bit of...)
4. King Africa - Bomba
5. El Barrio - Quiéreme
6. Estopa - La Raja De Tu Falda
7. ACDC - T.N.T
8. Proyecto Uno - El Tiburón
9. La Fiesta - La canción del velero
10. Zapato Veloz - Tractor Amarillo
11. Bad Bunny - Yo Perreo Sola
12. El Simbolo - Levantando Las Manos
13. Flying free - Pont Aeri
14. Santa Fe - Esto Es Pa Ti
15. Myke Towers - LA FALDA

---

## Cartón 78

1. Pitbull - El Taxi
2. The Refrescos - Aquí No Hay Playa
3. LOS LUNNIS - HASTA MAÑANA
4. Las Ketchup - Aserejé
5. Gente De Zona - La Gozadera
6. David Civera - Que La Detengan
7. Los chicanos del sur - Beso a beso
8. Daddy Yankee - Limbo
9. ROSALÍA, J Balvin - Con Altura
10. Chocolate - Mayonesa
11. Chimbala - Feliz
12. Radio Futura - Escuela de Calor
13. Baby Lores - La Mujer del Pelotero
14. María Isabel - Antes muerta que sencilla
15. Mano Negra - Mala Vida

---

## Cartón 79

1. Radio Futura - Escuela de Calor
2. CNCO - Reggaetón Lento (Bailemos)
3. Pereza - Princesas
4. El chombo - El gato volador
5. El chaval de la peca - Abanibi
6. Mambo No. 5 (A Little Bit of...)
7. ROSALÍA - DESPECHÁ
8. Alaska y Dinarama - A Quién Le Importa
9. La Hungara - Achilipu
10. Camilo - Vida de Rico
11. Seguridad social - Chiquilla
12. Rauw Alejandro - Todo de Ti
13. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
14. IZAL - La mujer de verde
15. La Pegatina - MariCarmen

---

## Cartón 80

1. Eivissa - Oh La La La
2. Juan Magán - Bailando por Ahi
3. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
4. Dos Gardenias - Dos Gardenias
5. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
6. Aitana - LAS BABYS
7. IZAL - La mujer de verde
8. Macaco - Ojala no te hubiera conocido nunca
9. Los Del Río - Macarena
10. LOS LUNNIS - HASTA MAÑANA
11. La Hungara - Achilipu
12. DON OMAR - DILE, CUENTALE (BATUCADA)
13. David Civera - Que La Detengan
14. King Africa - Paquito el chocolatero
15. ACDC - T.N.T

---

## Cartón 81

1. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
2. Bad Bunny - Yo Perreo Sola
3. IZAL - La mujer de verde
4. Daddy Yankee Feat. Omega - Estrellita De Madrugada
5. Blues Brothers - Everybody Needs Somebody To Love
6. Raphael - Mi Gran noche
7. Lola Indigo - LA REINA
8. Los Del Río - Macarena
9. Myke Towers - LA FALDA
10. Georgie Dann - La Barbacoa
11. Climax - Mesa Que Mas Aplauda
12. El Barrio - Quiéreme
13. Carlinhos Brown and DJ Dero - Maria caipirinha
14. Alaska y Dinarama - A Quién Le Importa
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 82

1. Hector y Tito ft. Don Omar - Baila morena
2. Melendi - Caminando por la Vida
3. SHAKIRA - BZRP Music Sessions #53
4. The Refrescos - Aquí No Hay Playa
5. David Bisbal y Aitana - Si Tú La Quieres
6. Georgie Dann - La Barbacoa
7. Pitbull - El Taxi
8. El chaval de la peca - Abanibi
9. Cue Dj - El Baile Del Serrucho
10. Dos Gardenias - Dos Gardenias
11. Gasolina - Daddy Yankee
12. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
13. María Isabel - Antes muerta que sencilla
14. Blues Brothers - Everybody Needs Somebody To Love
15. El Consorcio - El chacachá del tren

---

## Cartón 83

1. Katy Perry - Roar
2. Tequila - Salta
3. Santa Fe - Esto Es Pa Ti
4. Eivissa - Oh La La La
5. Proyecto Uno - El Tiburón
6. Cue Dj - El Baile Del Serrucho
7. LOS LUNNIS - HASTA MAÑANA
8. Marta, Sebas, Guille y los demás (Amaral)
9. SHAKIRA - BZRP Music Sessions #53
10. El Barrio - Quiéreme
11. El canto del loco - Zapatillas
12. Nino Bravo - Libre
13. King Africa - Bomba
14. Mano Negra - Mala Vida
15. Raphael - Mi Gran noche

---

## Cartón 84

1. Flying free - Pont Aeri
2. Paulina Rubio - Y Yo Sigo Aqui
3. Estopa - La Raja De Tu Falda
4. Carlinhos Brown and DJ Dero - Maria caipirinha
5. El Hormiguero - Marron
6. Las Ketchup - Aserejé
7. Pitbull - El Taxi
8. La Fiesta - La canción del velero
9. Los Delincuentes - Nube de Pegatina
10. Daddy Yankee - Limbo
11. Cue Dj - El Baile Del Serrucho
12. Los Rodriguez - Hace Calor
13. El Consorcio - El chacachá del tren
14. Isabel Aaiún - El Himno de Mi Peña
15. Gente De Zona - La Gozadera

---

## Cartón 85

1. CNCO - Reggaetón Lento (Bailemos)
2. Pereza - Princesas
3. Myke Towers - LA FALDA
4. Isabel Aaiún - El Himno de Mi Peña
5. IZAL - La mujer de verde
6. Vicco - Nochentera
7. SBS - Sigue Al Lider (Follow The Leader)
8. Macaco - Ojala no te hubiera conocido nunca
9. Radio Futura - Escuela de Calor
10. Melendi - Caminando por la Vida
11. El Hormiguero - Marron
12. José Luis Perales - Un Velero Llamado Libertad
13. Cali Flow Latino - Ras Tas Tas
14. KAROL G - Si Antes Te Hubiera Conocido
15. Flying free - Pont Aeri

---

## Cartón 86

1. Los Rodriguez - Hace Calor
2. King Africa - Bomba
3. El Simbolo - Levantando Las Manos
4. Joaquin Sabina - Y Nos Dieron las Diez (Video)
5. Nino Bravo - Libre
6. El Hormiguero - Marron
7. ROSALÍA - DESPECHÁ
8. María Isabel - Antes muerta que sencilla
9. Paulina Rubio - Y Yo Sigo Aqui
10. Don Omar - Danza Kuduro
11. KAROL G - Si Antes Te Hubiera Conocido
12. Los Manolos - All my Lovin
13. King Africa - Paquito el chocolatero
14. El chaval de la peca - Abanibi
15. Jarabe de Palo - Eso que tú me das

---

## Cartón 87

1. Bad Bunny - Yo Perreo Sola
2. BM y Luck Ra - La Morocha
3. Hector y Tito ft. Don Omar - Baila morena
4. David Bisbal y Aitana - Si Tú La Quieres
5. Juan Magán - Bailando por Ahi
6. ROSÉ y Bruno Mars - APT.
7. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
8. Tequila - Salta
9. Nino Bravo - Libre
10. La Fiesta - La canción del velero
11. Zapato Veloz - Tractor Amarillo
12. Jarabe de Palo - Eso que tú me das
13. Camilo - Vida de Rico
14. La Oreja de Van Gogh - Rosas
15. Camela - Cuando zarpa el amor

---

## Cartón 88

1. Lola Indigo - LA REINA
2. Katy Perry - Roar
3. La Pegatina - MariCarmen
4. ACDC - T.N.T
5. Chimbala - Feliz
6. David Bisbal y Aitana - Si Tú La Quieres
7. Gasolina - Daddy Yankee
8. Aitana - LAS BABYS
9. Isabel Aaiún - El Himno de Mi Peña
10. Los Delincuentes - Nube de Pegatina
11. Vicco - Nochentera
12. Climax - Mesa Que Mas Aplauda
13. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
14. Gente De Zona - La Gozadera
15. ROSALÍA, J Balvin - Con Altura

---

## Cartón 89

1. The Refrescos - Aquí No Hay Playa
2. Mano Negra - Mala Vida
3. Dos Gardenias - Dos Gardenias
4. Melendi - Caminando por la Vida
5. Climax - Mesa Que Mas Aplauda
6. Flying free - Pont Aeri
7. La Pegatina - MariCarmen
8. El Barrio - Quiéreme
9. Baby Lores - La Mujer del Pelotero
10. Blues Brothers - Everybody Needs Somebody To Love
11. Daddy Yankee Feat. Omega - Estrellita De Madrugada
12. Don Omar - Danza Kuduro
13. Alaska y Dinarama - A Quién Le Importa
14. Coyote Dax - No Rompas Mi Corazón
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 90

1. SBS - Sigue Al Lider (Follow The Leader)
2. Radio Futura - Escuela de Calor
3. King Africa - Bomba
4. BM y Luck Ra - La Morocha
5. Daddy Yankee - Limbo
6. Pitbull - El Taxi
7. Proyecto Uno - El Tiburón
8. Rauw Alejandro - Todo de Ti
9. Los Rodriguez - Hace Calor
10. Lola Indigo - LA REINA
11. ROSALÍA - DESPECHÁ
12. DON OMAR - DILE, CUENTALE (BATUCADA)
13. La Hungara - Achilipu
14. Mambo No. 5 (A Little Bit of...)
15. José Luis Perales - Un Velero Llamado Libertad

---

## Cartón 91

1. Zapato Veloz - Tractor Amarillo
2. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
3. Los Manolos - All my Lovin
4. La Hungara - Achilipu
5. Coyote Dax - No Rompas Mi Corazón
6. Daddy Yankee Feat. Omega - Estrellita De Madrugada
7. Camela - Cuando zarpa el amor
8. La Oreja de Van Gogh - Rosas
9. El chaval de la peca - Abanibi
10. ROSÉ y Bruno Mars - APT.
11. Chocolate - Mayonesa
12. Hector y Tito ft. Don Omar - Baila morena
13. Los Del Río - Macarena
14. Chimbala - Feliz
15. ACDC - T.N.T

---

## Cartón 92

1. Gente De Zona - La Gozadera
2. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
3. DON OMAR - DILE, CUENTALE (BATUCADA)
4. Joaquin Sabina - Y Nos Dieron las Diez (Video)
5. Coyote Dax - No Rompas Mi Corazón
6. Macaco - Ojala no te hubiera conocido nunca
7. La Pegatina - MariCarmen
8. Baby Lores - La Mujer del Pelotero
9. Tequila - Salta
10. Paulina Rubio - Y Yo Sigo Aqui
11. Sebastián Yatra - Tacones Rojos
12. Zapato Veloz - Tractor Amarillo
13. Santa Fe - Esto Es Pa Ti
14. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
15. La Fiesta - La canción del velero

---

## Cartón 93

1. Aitana - LAS BABYS
2. The Refrescos - Aquí No Hay Playa
3. SHAKIRA - BZRP Music Sessions #53
4. Los Delincuentes - Nube de Pegatina
5. Los Manolos - All my Lovin
6. KAROL G - Si Antes Te Hubiera Conocido
7. Carlinhos Brown and DJ Dero - Maria caipirinha
8. LOS LUNNIS - HASTA MAÑANA
9. Gasolina - Daddy Yankee
10. Santa Fe - Esto Es Pa Ti
11. Joaquin Sabina - Y Nos Dieron las Diez (Video)
12. Los chicanos del sur - Beso a beso
13. Camela - Cuando zarpa el amor
14. King Africa - Bomba
15. Marta, Sebas, Guille y los demás (Amaral)

---

## Cartón 94

1. Jarabe de Palo - Eso que tú me das
2. Seguridad social - Chiquilla
3. Katy Perry - Roar
4. Coyote Dax - No Rompas Mi Corazón
5. DON OMAR - DILE, CUENTALE (BATUCADA)
6. Pereza - Princesas
7. Proyecto Uno - El Tiburón
8. Cali Flow Latino - Ras Tas Tas
9. Juan Magán - Bailando por Ahi
10. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
11. Santa Fe - Esto Es Pa Ti
12. Chimbala - Feliz
13. Camilo - Vida de Rico
14. Isabel Aaiún - El Himno de Mi Peña
15. CNCO - Reggaetón Lento (Bailemos)

---

## Cartón 95

1. Eivissa - Oh La La La
2. Alaska y Dinarama - A Quién Le Importa
3. Bad Bunny - Yo Perreo Sola
4. David Civera - Que La Detengan
5. Vicco - Nochentera
6. SBS - Sigue Al Lider (Follow The Leader)
7. Chocolate - Mayonesa
8. ROSALÍA, J Balvin - Con Altura
9. Pereza - Princesas
10. El Barrio - Quiéreme
11. King Africa - Paquito el chocolatero
12. Carlinhos Brown and DJ Dero - Maria caipirinha
13. José Luis Perales - Un Velero Llamado Libertad
14. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
15. Estopa - La Raja De Tu Falda

---

## Cartón 96

1. Dos Gardenias - Dos Gardenias
2. King Africa - Paquito el chocolatero
3. Macaco - Ojala no te hubiera conocido nunca
4. Sebastián Yatra - Tacones Rojos
5. ROSALÍA, J Balvin - Con Altura
6. La Oreja de Van Gogh - Rosas
7. BM y Luck Ra - La Morocha
8. David Bisbal y Aitana - Si Tú La Quieres
9. Raphael - Mi Gran noche
10. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
11. Rauw Alejandro - Todo de Ti
12. Blues Brothers - Everybody Needs Somebody To Love
13. ROSÉ y Bruno Mars - APT.
14. El Simbolo - Levantando Las Manos
15. Daddy Yankee - Limbo

---

## Cartón 97

1. Carlinhos Brown and DJ Dero - Maria caipirinha
2. Zapato Veloz - Tractor Amarillo
3. Myke Towers - LA FALDA
4. Lola Indigo - LA REINA
5. LOS LUNNIS - HASTA MAÑANA
6. Sebastián Yatra - Tacones Rojos
7. Vicco - Nochentera
8. Joaquin Sabina - Y Nos Dieron las Diez (Video)
9. El canto del loco - Zapatillas
10. El Simbolo - Levantando Las Manos
11. El Consorcio - El chacachá del tren
12. El chombo - El gato volador
13. Mambo No. 5 (A Little Bit of...)
14. Mano Negra - Mala Vida
15. Aitana - LAS BABYS

---

## Cartón 98

1. María Isabel - Antes muerta que sencilla
2. Katy Perry - Roar
3. Alaska y Dinarama - A Quién Le Importa
4. Paulina Rubio - Y Yo Sigo Aqui
5. Cali Flow Latino - Ras Tas Tas
6. El Hormiguero - Marron
7. Los Delincuentes - Nube de Pegatina
8. The Refrescos - Aquí No Hay Playa
9. Pitbull - El Taxi
10. KAROL G - Si Antes Te Hubiera Conocido
11. ROSALÍA - DESPECHÁ
12. Georgie Dann - La Barbacoa
13. Jarabe de Palo - Eso que tú me das
14. Melendi - Caminando por la Vida
15. Myke Towers - LA FALDA

---

## Cartón 99

1. Seguridad social - Chiquilla
2. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
3. Hector y Tito ft. Don Omar - Baila morena
4. El canto del loco - Zapatillas
5. Los chicanos del sur - Beso a beso
6. Gente De Zona - La Gozadera
7. ACDC - T.N.T
8. Los Manolos - All my Lovin
9. Dos Gardenias - Dos Gardenias
10. CNCO - Reggaetón Lento (Bailemos)
11. Estopa - La Raja De Tu Falda
12. Isabel Aaiún - El Himno de Mi Peña
13. Don Omar - Danza Kuduro
14. Raphael - Mi Gran noche
15. Blues Brothers - Everybody Needs Somebody To Love

---

## Cartón 100

1. Radio Futura - Escuela de Calor
2. Juan Magán - Bailando por Ahi
3. Marta, Sebas, Guille y los demás (Amaral)
4. Katy Perry - Roar
5. Nino Bravo - Libre
6. Chimbala - Feliz
7. LOS LUNNIS - HASTA MAÑANA
8. Isabel Aaiún - El Himno de Mi Peña
9. SHAKIRA - BZRP Music Sessions #53
10. BM y Luck Ra - La Morocha
11. Flying free - Pont Aeri
12. Daddy Yankee Feat. Omega - Estrellita De Madrugada
13. Eivissa - Oh La La La
14. Las Ketchup - Aserejé
15. Seguridad social - Chiquilla

---

## Cartón 101

1. El chombo - El gato volador
2. Pitbull - El Taxi
3. Alaska y Dinarama - A Quién Le Importa
4. Climax - Mesa Que Mas Aplauda
5. Myke Towers - LA FALDA
6. Mano Negra - Mala Vida
7. Los chicanos del sur - Beso a beso
8. La Fiesta - La canción del velero
9. El Hormiguero - Marron
10. ROSALÍA, J Balvin - Con Altura
11. Chocolate - Mayonesa
12. IZAL - La mujer de verde
13. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
14. Juan Magán - Bailando por Ahi
15. Tequila - Salta

---

## Cartón 102

1. La Fiesta - La canción del velero
2. Cue Dj - El Baile Del Serrucho
3. La Hungara - Achilipu
4. Eivissa - Oh La La La
5. La Pegatina - MariCarmen
6. El Consorcio - El chacachá del tren
7. Los Del Río - Macarena
8. Proyecto Uno - El Tiburón
9. El chaval de la peca - Abanibi
10. ACDC - T.N.T
11. Santa Fe - Esto Es Pa Ti
12. Lola Indigo - LA REINA
13. Flying free - Pont Aeri
14. María Isabel - Antes muerta que sencilla
15. Paulina Rubio - Y Yo Sigo Aqui

---

## Cartón 103

1. La Fiesta - La canción del velero
2. Los Delincuentes - Nube de Pegatina
3. Nino Bravo - Libre
4. Macaco - Ojala no te hubiera conocido nunca
5. Seguridad social - Chiquilla
6. IZAL - La mujer de verde
7. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
8. Daddy Yankee - Limbo
9. Gasolina - Daddy Yankee
10. Marta, Sebas, Guille y los demás (Amaral)
11. ROSALÍA - DESPECHÁ
12. Rauw Alejandro - Todo de Ti
13. Los Manolos - All my Lovin
14. Vicco - Nochentera
15. Baby Lores - La Mujer del Pelotero

---

## Cartón 104

1. El canto del loco - Zapatillas
2. José Luis Perales - Un Velero Llamado Libertad
3. Radio Futura - Escuela de Calor
4. Pereza - Princesas
5. Blues Brothers - Everybody Needs Somebody To Love
6. SHAKIRA - BZRP Music Sessions #53
7. Georgie Dann - La Barbacoa
8. ROSÉ y Bruno Mars - APT.
9. El Barrio - Quiéreme
10. King Africa - Bomba
11. Camilo - Vida de Rico
12. La Hungara - Achilipu
13. CNCO - Reggaetón Lento (Bailemos)
14. ROSALÍA, J Balvin - Con Altura
15. Los chicanos del sur - Beso a beso

---

## Cartón 105

1. Cali Flow Latino - Ras Tas Tas
2. El chaval de la peca - Abanibi
3. Camilo - Vida de Rico
4. KAROL G - Si Antes Te Hubiera Conocido
5. El chombo - El gato volador
6. Proyecto Uno - El Tiburón
7. DON OMAR - DILE, CUENTALE (BATUCADA)
8. Las Ketchup - Aserejé
9. Gasolina - Daddy Yankee
10. Carlinhos Brown and DJ Dero - Maria caipirinha
11. King Africa - Paquito el chocolatero
12. ROSÉ y Bruno Mars - APT.
13. Gente De Zona - La Gozadera
14. Flying free - Pont Aeri
15. David Civera - Que La Detengan

---

## Cartón 106

1. Los Rodriguez - Hace Calor
2. La Pegatina - MariCarmen
3. El canto del loco - Zapatillas
4. El Simbolo - Levantando Las Manos
5. Daddy Yankee - Limbo
6. Bad Bunny - Yo Perreo Sola
7. Melendi - Caminando por la Vida
8. Myke Towers - LA FALDA
9. Paulina Rubio - Y Yo Sigo Aqui
10. Las Ketchup - Aserejé
11. Cue Dj - El Baile Del Serrucho
12. Rauw Alejandro - Todo de Ti
13. Tequila - Salta
14. Jarabe de Palo - Eso que tú me das
15. The Refrescos - Aquí No Hay Playa

---

## Cartón 107

1. Baby Lores - La Mujer del Pelotero
2. El Hormiguero - Marron
3. ROSALÍA - DESPECHÁ
4. SBS - Sigue Al Lider (Follow The Leader)
5. Alaska y Dinarama - A Quién Le Importa
6. Camela - Cuando zarpa el amor
7. Bad Bunny - Yo Perreo Sola
8. David Bisbal y Aitana - Si Tú La Quieres
9. Chimbala - Feliz
10. Los Rodriguez - Hace Calor
11. Chocolate - Mayonesa
12. Estopa - La Raja De Tu Falda
13. Katy Perry - Roar
14. The Refrescos - Aquí No Hay Playa
15. Lola Indigo - LA REINA

---

## Cartón 108

1. La Oreja de Van Gogh - Rosas
2. Marta, Sebas, Guille y los demás (Amaral)
3. ACDC - T.N.T
4. Pereza - Princesas
5. David Bisbal y Aitana - Si Tú La Quieres
6. Santa Fe - Esto Es Pa Ti
7. Macaco - Ojala no te hubiera conocido nunca
8. Mambo No. 5 (A Little Bit of...)
9. Climax - Mesa Que Mas Aplauda
10. BM y Luck Ra - La Morocha
11. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
12. Camela - Cuando zarpa el amor
13. Joaquin Sabina - Y Nos Dieron las Diez (Video)
14. El Hormiguero - Marron
15. Los Delincuentes - Nube de Pegatina

---

## Cartón 109

1. La Pegatina - MariCarmen
2. Los Rodriguez - Hace Calor
3. Don Omar - Danza Kuduro
4. IZAL - La mujer de verde
5. Joaquin Sabina - Y Nos Dieron las Diez (Video)
6. El chaval de la peca - Abanibi
7. Climax - Mesa Que Mas Aplauda
8. Dos Gardenias - Dos Gardenias
9. Mano Negra - Mala Vida
10. La Hungara - Achilipu
11. Georgie Dann - La Barbacoa
12. SHAKIRA - BZRP Music Sessions #53
13. CNCO - Reggaetón Lento (Bailemos)
14. Daddy Yankee Feat. Omega - Estrellita De Madrugada
15. Raphael - Mi Gran noche

---

## Cartón 110

1. Carlinhos Brown and DJ Dero - Maria caipirinha
2. Aitana - LAS BABYS
3. Gasolina - Daddy Yankee
4. María Isabel - Antes muerta que sencilla
5. José Luis Perales - Un Velero Llamado Libertad
6. King Africa - Paquito el chocolatero
7. Pitbull - El Taxi
8. Vicco - Nochentera
9. Zapato Veloz - Tractor Amarillo
10. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
11. Los chicanos del sur - Beso a beso
12. Proyecto Uno - El Tiburón
13. El Simbolo - Levantando Las Manos
14. Los Del Río - Macarena
15. Nino Bravo - Libre

---

## Cartón 111

1. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
2. El chombo - El gato volador
3. Marta, Sebas, Guille y los demás (Amaral)
4. Coyote Dax - No Rompas Mi Corazón
5. El chaval de la peca - Abanibi
6. Gente De Zona - La Gozadera
7. La Oreja de Van Gogh - Rosas
8. ROSALÍA - DESPECHÁ
9. Daddy Yankee Feat. Omega - Estrellita De Madrugada
10. Mano Negra - Mala Vida
11. Cali Flow Latino - Ras Tas Tas
12. Hector y Tito ft. Don Omar - Baila morena
13. María Isabel - Antes muerta que sencilla
14. Pitbull - El Taxi
15. Alaska y Dinarama - A Quién Le Importa

---

## Cartón 112

1. Proyecto Uno - El Tiburón
2. KAROL G - Si Antes Te Hubiera Conocido
3. Isabel Aaiún - El Himno de Mi Peña
4. Bad Bunny - Yo Perreo Sola
5. David Civera - Que La Detengan
6. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
7. Cue Dj - El Baile Del Serrucho
8. Sebastián Yatra - Tacones Rojos
9. IZAL - La mujer de verde
10. Las Ketchup - Aserejé
11. Chimbala - Feliz
12. King Africa - Bomba
13. ROSALÍA, J Balvin - Con Altura
14. El Simbolo - Levantando Las Manos
15. Raphael - Mi Gran noche

---

## Cartón 113

1. Macaco - Ojala no te hubiera conocido nunca
2. Carlinhos Brown and DJ Dero - Maria caipirinha
3. Daddy Yankee - Limbo
4. El chombo - El gato volador
5. ROSALÍA - DESPECHÁ
6. BM y Luck Ra - La Morocha
7. Dos Gardenias - Dos Gardenias
8. Nino Bravo - Libre
9. Mambo No. 5 (A Little Bit of...)
10. IZAL - La mujer de verde
11. Don Omar - Danza Kuduro
12. Camela - Cuando zarpa el amor
13. Blues Brothers - Everybody Needs Somebody To Love
14. El Consorcio - El chacachá del tren
15. Hector y Tito ft. Don Omar - Baila morena

---

## Cartón 114

1. Estopa - La Raja De Tu Falda
2. Isabel Aaiún - El Himno de Mi Peña
3. Georgie Dann - La Barbacoa
4. Jarabe de Palo - Eso que tú me das
5. La Hungara - Achilipu
6. Gasolina - Daddy Yankee
7. José Luis Perales - Un Velero Llamado Libertad
8. Myke Towers - LA FALDA
9. Hector y Tito ft. Don Omar - Baila morena
10. Chocolate - Mayonesa
11. Melendi - Caminando por la Vida
12. Los Del Río - Macarena
13. ROSÉ y Bruno Mars - APT.
14. Baby Lores - La Mujer del Pelotero
15. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer

---

## Cartón 115

1. El canto del loco - Zapatillas
2. Radio Futura - Escuela de Calor
3. Coyote Dax - No Rompas Mi Corazón
4. SBS - Sigue Al Lider (Follow The Leader)
5. Tequila - Salta
6. ROSÉ y Bruno Mars - APT.
7. Los Manolos - All my Lovin
8. Juan Magán - Bailando por Ahi
9. ROSALÍA - DESPECHÁ
10. Aitana - LAS BABYS
11. Los chicanos del sur - Beso a beso
12. María Isabel - Antes muerta que sencilla
13. El Consorcio - El chacachá del tren
14. El Barrio - Quiéreme
15. Dos Gardenias - Dos Gardenias

---

## Cartón 116

1. Jarabe de Palo - Eso que tú me das
2. Dos Gardenias - Dos Gardenias
3. SHAKIRA - BZRP Music Sessions #53
4. DON OMAR - DILE, CUENTALE (BATUCADA)
5. Pereza - Princesas
6. Camilo - Vida de Rico
7. Georgie Dann - La Barbacoa
8. Los Manolos - All my Lovin
9. Seguridad social - Chiquilla
10. Raphael - Mi Gran noche
11. David Civera - Que La Detengan
12. El Barrio - Quiéreme
13. Aitana - LAS BABYS
14. El Consorcio - El chacachá del tren
15. El Hormiguero - Marron

---

## Cartón 117

1. Tequila - Salta
2. King Africa - Bomba
3. Isabel Aaiún - El Himno de Mi Peña
4. Vicco - Nochentera
5. David Bisbal y Aitana - Si Tú La Quieres
6. Rauw Alejandro - Todo de Ti
7. Camilo - Vida de Rico
8. Mambo No. 5 (A Little Bit of...)
9. Eivissa - Oh La La La
10. Cue Dj - El Baile Del Serrucho
11. Las Ketchup - Aserejé
12. LOS LUNNIS - HASTA MAÑANA
13. Marta, Sebas, Guille y los demás (Amaral)
14. BM y Luck Ra - La Morocha
15. The Refrescos - Aquí No Hay Playa

---

## Cartón 118

1. Eivissa - Oh La La La
2. Los Rodriguez - Hace Calor
3. King Africa - Bomba
4. Rauw Alejandro - Todo de Ti
5. La Fiesta - La canción del velero
6. Estopa - La Raja De Tu Falda
7. Raphael - Mi Gran noche
8. El canto del loco - Zapatillas
9. Gente De Zona - La Gozadera
10. Joaquin Sabina - Y Nos Dieron las Diez (Video)
11. DON OMAR - DILE, CUENTALE (BATUCADA)
12. Radio Futura - Escuela de Calor
13. Melendi - Caminando por la Vida
14. KAROL G - Si Antes Te Hubiera Conocido
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 119

1. José Luis Perales - Un Velero Llamado Libertad
2. King Africa - Paquito el chocolatero
3. El chombo - El gato volador
4. Rauw Alejandro - Todo de Ti
5. La Pegatina - MariCarmen
6. Flying free - Pont Aeri
7. Baby Lores - La Mujer del Pelotero
8. Seguridad social - Chiquilla
9. Don Omar - Danza Kuduro
10. Zapato Veloz - Tractor Amarillo
11. Las Ketchup - Aserejé
12. Daddy Yankee Feat. Omega - Estrellita De Madrugada
13. Daddy Yankee - Limbo
14. La Oreja de Van Gogh - Rosas
15. SHAKIRA - BZRP Music Sessions #53

---

## Cartón 120

1. BM y Luck Ra - La Morocha
2. Myke Towers - LA FALDA
3. Paulina Rubio - Y Yo Sigo Aqui
4. Lola Indigo - LA REINA
5. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
6. Macaco - Ojala no te hubiera conocido nunca
7. SBS - Sigue Al Lider (Follow The Leader)
8. David Bisbal y Aitana - Si Tú La Quieres
9. LOS LUNNIS - HASTA MAÑANA
10. Seguridad social - Chiquilla
11. Zapato Veloz - Tractor Amarillo
12. ACDC - T.N.T
13. Sebastián Yatra - Tacones Rojos
14. Los chicanos del sur - Beso a beso
15. Daddy Yankee - Limbo

---

## Cartón 121

1. Blues Brothers - Everybody Needs Somebody To Love
2. Chocolate - Mayonesa
3. Chimbala - Feliz
4. Gente De Zona - La Gozadera
5. Los Delincuentes - Nube de Pegatina
6. María Isabel - Antes muerta que sencilla
7. Los Del Río - Macarena
8. Paulina Rubio - Y Yo Sigo Aqui
9. El Simbolo - Levantando Las Manos
10. Melendi - Caminando por la Vida
11. Carlinhos Brown and DJ Dero - Maria caipirinha
12. Flying free - Pont Aeri
13. Climax - Mesa Que Mas Aplauda
14. Santa Fe - Esto Es Pa Ti
15. Mano Negra - Mala Vida

---

## Cartón 122

1. Estopa - La Raja De Tu Falda
2. Gente De Zona - La Gozadera
3. Jarabe de Palo - Eso que tú me das
4. Cali Flow Latino - Ras Tas Tas
5. Bad Bunny - Yo Perreo Sola
6. Chocolate - Mayonesa
7. Marta, Sebas, Guille y los demás (Amaral)
8. El Barrio - Quiéreme
9. Coyote Dax - No Rompas Mi Corazón
10. Katy Perry - Roar
11. Los Delincuentes - Nube de Pegatina
12. ROSALÍA - DESPECHÁ
13. Gasolina - Daddy Yankee
14. David Civera - Que La Detengan
15. ROSALÍA, J Balvin - Con Altura

---

## Cartón 123

1. Climax - Mesa Que Mas Aplauda
2. KAROL G - Si Antes Te Hubiera Conocido
3. Lola Indigo - LA REINA
4. El chombo - El gato volador
5. Radio Futura - Escuela de Calor
6. Camilo - Vida de Rico
7. Santa Fe - Esto Es Pa Ti
8. Bad Bunny - Yo Perreo Sola
9. Vicco - Nochentera
10. Chimbala - Feliz
11. José Luis Perales - Un Velero Llamado Libertad
12. Los Manolos - All my Lovin
13. Los chicanos del sur - Beso a beso
14. El Hormiguero - Marron
15. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul

---

## Cartón 124

1. José Luis Perales - Un Velero Llamado Libertad
2. La Pegatina - MariCarmen
3. Los Rodriguez - Hace Calor
4. Chimbala - Feliz
5. El canto del loco - Zapatillas
6. Melendi - Caminando por la Vida
7. ACDC - T.N.T
8. Juan Magán - Bailando por Ahi
9. Las Ketchup - Aserejé
10. Zapato Veloz - Tractor Amarillo
11. Pitbull - El Taxi
12. Nino Bravo - Libre
13. Tequila - Salta
14. Hector y Tito ft. Don Omar - Baila morena
15. DON OMAR - DILE, CUENTALE (BATUCADA)

---

## Cartón 125

1. El Barrio - Quiéreme
2. LOS LUNNIS - HASTA MAÑANA
3. Macaco - Ojala no te hubiera conocido nunca
4. Paulina Rubio - Y Yo Sigo Aqui
5. Estopa - La Raja De Tu Falda
6. ROSALÍA, J Balvin - Con Altura
7. Pitbull - El Taxi
8. La Fiesta - La canción del velero
9. La Oreja de Van Gogh - Rosas
10. ROSÉ y Bruno Mars - APT.
11. Don Omar - Danza Kuduro
12. Blues Brothers - Everybody Needs Somebody To Love
13. Georgie Dann - La Barbacoa
14. El Consorcio - El chacachá del tren
15. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul

---

## Cartón 126

1. Juan Magán - Bailando por Ahi
2. Coyote Dax - No Rompas Mi Corazón
3. Cue Dj - El Baile Del Serrucho
4. El chaval de la peca - Abanibi
5. CNCO - Reggaetón Lento (Bailemos)
6. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
7. ACDC - T.N.T
8. Gente De Zona - La Gozadera
9. Los Delincuentes - Nube de Pegatina
10. Pereza - Princesas
11. Melendi - Caminando por la Vida
12. Marta, Sebas, Guille y los demás (Amaral)
13. Alaska y Dinarama - A Quién Le Importa
14. Mano Negra - Mala Vida
15. Daddy Yankee Feat. Omega - Estrellita De Madrugada

---

## Cartón 127

1. Rauw Alejandro - Todo de Ti
2. Camela - Cuando zarpa el amor
3. King Africa - Paquito el chocolatero
4. Coyote Dax - No Rompas Mi Corazón
5. La Oreja de Van Gogh - Rosas
6. La Hungara - Achilipu
7. SBS - Sigue Al Lider (Follow The Leader)
8. Jarabe de Palo - Eso que tú me das
9. Raphael - Mi Gran noche
10. Hector y Tito ft. Don Omar - Baila morena
11. Pereza - Princesas
12. David Civera - Que La Detengan
13. Aitana - LAS BABYS
14. IZAL - La mujer de verde
15. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul

---

## Cartón 128

1. Nino Bravo - Libre
2. El Hormiguero - Marron
3. ROSÉ y Bruno Mars - APT.
4. IZAL - La mujer de verde
5. CNCO - Reggaetón Lento (Bailemos)
6. The Refrescos - Aquí No Hay Playa
7. Myke Towers - LA FALDA
8. Mano Negra - Mala Vida
9. Los Del Río - Macarena
10. Santa Fe - Esto Es Pa Ti
11. El Simbolo - Levantando Las Manos
12. Cali Flow Latino - Ras Tas Tas
13. David Civera - Que La Detengan
14. Daddy Yankee Feat. Omega - Estrellita De Madrugada
15. Katy Perry - Roar

---

## Cartón 129

1. Carlinhos Brown and DJ Dero - Maria caipirinha
2. David Bisbal y Aitana - Si Tú La Quieres
3. King Africa - Bomba
4. Vicco - Nochentera
5. Joaquin Sabina - Y Nos Dieron las Diez (Video)
6. Georgie Dann - La Barbacoa
7. Los Rodriguez - Hace Calor
8. Eivissa - Oh La La La
9. LOS LUNNIS - HASTA MAÑANA
10. Cue Dj - El Baile Del Serrucho
11. Mambo No. 5 (A Little Bit of...)
12. Baby Lores - La Mujer del Pelotero
13. Proyecto Uno - El Tiburón
14. Mano Negra - Mala Vida
15. El Barrio - Quiéreme

---

## Cartón 130

1. SHAKIRA - BZRP Music Sessions #53
2. CNCO - Reggaetón Lento (Bailemos)
3. El chombo - El gato volador
4. La Hungara - Achilipu
5. Tequila - Salta
6. Zapato Veloz - Tractor Amarillo
7. José Luis Perales - Un Velero Llamado Libertad
8. Don Omar - Danza Kuduro
9. Isabel Aaiún - El Himno de Mi Peña
10. Seguridad social - Chiquilla
11. Climax - Mesa Que Mas Aplauda
12. Los Manolos - All my Lovin
13. The Refrescos - Aquí No Hay Playa
14. Mambo No. 5 (A Little Bit of...)
15. Eivissa - Oh La La La

---

## Cartón 131

1. Aitana - LAS BABYS
2. La Fiesta - La canción del velero
3. Myke Towers - LA FALDA
4. El chaval de la peca - Abanibi
5. Sebastián Yatra - Tacones Rojos
6. Mambo No. 5 (A Little Bit of...)
7. Dos Gardenias - Dos Gardenias
8. Daddy Yankee - Limbo
9. Zapato Veloz - Tractor Amarillo
10. Joaquin Sabina - Y Nos Dieron las Diez (Video)
11. Gasolina - Daddy Yankee
12. Juan Magán - Bailando por Ahi
13. DON OMAR - DILE, CUENTALE (BATUCADA)
14. SBS - Sigue Al Lider (Follow The Leader)
15. Katy Perry - Roar

---

## Cartón 132

1. El Consorcio - El chacachá del tren
2. Cali Flow Latino - Ras Tas Tas
3. KAROL G - Si Antes Te Hubiera Conocido
4. La Pegatina - MariCarmen
5. Flying free - Pont Aeri
6. Los Manolos - All my Lovin
7. Alaska y Dinarama - A Quién Le Importa
8. Chocolate - Mayonesa
9. Pitbull - El Taxi
10. Blues Brothers - Everybody Needs Somebody To Love
11. El Hormiguero - Marron
12. Baby Lores - La Mujer del Pelotero
13. Las Ketchup - Aserejé
14. Melendi - Caminando por la Vida
15. Coyote Dax - No Rompas Mi Corazón

---

## Cartón 133

1. El Consorcio - El chacachá del tren
2. El canto del loco - Zapatillas
3. The Refrescos - Aquí No Hay Playa
4. ROSÉ y Bruno Mars - APT.
5. David Civera - Que La Detengan
6. David Bisbal y Aitana - Si Tú La Quieres
7. Cali Flow Latino - Ras Tas Tas
8. Radio Futura - Escuela de Calor
9. King Africa - Paquito el chocolatero
10. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
11. Camela - Cuando zarpa el amor
12. Aitana - LAS BABYS
13. Georgie Dann - La Barbacoa
14. Proyecto Uno - El Tiburón
15. King Africa - Bomba

---

## Cartón 134

1. Los Del Río - Macarena
2. El chombo - El gato volador
3. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
4. Tequila - Salta
5. ROSALÍA - DESPECHÁ
6. BM y Luck Ra - La Morocha
7. Macaco - Ojala no te hubiera conocido nunca
8. Paulina Rubio - Y Yo Sigo Aqui
9. Nino Bravo - Libre
10. Gasolina - Daddy Yankee
11. Mano Negra - Mala Vida
12. Blues Brothers - Everybody Needs Somebody To Love
13. ROSALÍA, J Balvin - Con Altura
14. María Isabel - Antes muerta que sencilla
15. Sebastián Yatra - Tacones Rojos

---

## Cartón 135

1. Blues Brothers - Everybody Needs Somebody To Love
2. Alaska y Dinarama - A Quién Le Importa
3. Seguridad social - Chiquilla
4. BM y Luck Ra - La Morocha
5. El chaval de la peca - Abanibi
6. Estopa - La Raja De Tu Falda
7. La Pegatina - MariCarmen
8. La Hungara - Achilipu
9. DON OMAR - DILE, CUENTALE (BATUCADA)
10. Los Del Río - Macarena
11. LOS LUNNIS - HASTA MAÑANA
12. Eivissa - Oh La La La
13. Camilo - Vida de Rico
14. Carlinhos Brown and DJ Dero - Maria caipirinha
15. Flying free - Pont Aeri

---

## Cartón 136

1. Marta, Sebas, Guille y los demás (Amaral)
2. Seguridad social - Chiquilla
3. Lola Indigo - LA REINA
4. Raphael - Mi Gran noche
5. María Isabel - Antes muerta que sencilla
6. KAROL G - Si Antes Te Hubiera Conocido
7. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
8. El chombo - El gato volador
9. Pereza - Princesas
10. King Africa - Paquito el chocolatero
11. Vicco - Nochentera
12. Katy Perry - Roar
13. DON OMAR - DILE, CUENTALE (BATUCADA)
14. SBS - Sigue Al Lider (Follow The Leader)
15. La Fiesta - La canción del velero

---

## Cartón 137

1. LOS LUNNIS - HASTA MAÑANA
2. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
3. Camilo - Vida de Rico
4. Daddy Yankee - Limbo
5. CNCO - Reggaetón Lento (Bailemos)
6. Bad Bunny - Yo Perreo Sola
7. Los chicanos del sur - Beso a beso
8. Vicco - Nochentera
9. Joaquin Sabina - Y Nos Dieron las Diez (Video)
10. DON OMAR - DILE, CUENTALE (BATUCADA)
11. Proyecto Uno - El Tiburón
12. Don Omar - Danza Kuduro
13. El canto del loco - Zapatillas
14. IZAL - La mujer de verde
15. Radio Futura - Escuela de Calor

---

## Cartón 138

1. Los Del Río - Macarena
2. Rauw Alejandro - Todo de Ti
3. Jarabe de Palo - Eso que tú me das
4. Cue Dj - El Baile Del Serrucho
5. Baby Lores - La Mujer del Pelotero
6. Los Delincuentes - Nube de Pegatina
7. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
8. Dos Gardenias - Dos Gardenias
9. Gasolina - Daddy Yankee
10. ACDC - T.N.T
11. Marta, Sebas, Guille y los demás (Amaral)
12. El Simbolo - Levantando Las Manos
13. Estopa - La Raja De Tu Falda
14. Georgie Dann - La Barbacoa
15. María Isabel - Antes muerta que sencilla

---

## Cartón 139

1. Gente De Zona - La Gozadera
2. Macaco - Ojala no te hubiera conocido nunca
3. Daddy Yankee Feat. Omega - Estrellita De Madrugada
4. La Oreja de Van Gogh - Rosas
5. Bad Bunny - Yo Perreo Sola
6. Tequila - Salta
7. Joaquin Sabina - Y Nos Dieron las Diez (Video)
8. Chimbala - Feliz
9. SHAKIRA - BZRP Music Sessions #53
10. IZAL - La mujer de verde
11. Chocolate - Mayonesa
12. Cue Dj - El Baile Del Serrucho
13. Jarabe de Palo - Eso que tú me das
14. El Consorcio - El chacachá del tren
15. Don Omar - Danza Kuduro

---

## Cartón 140

1. La Hungara - Achilipu
2. Dos Gardenias - Dos Gardenias
3. Isabel Aaiún - El Himno de Mi Peña
4. CNCO - Reggaetón Lento (Bailemos)
5. El Simbolo - Levantando Las Manos
6. ROSÉ y Bruno Mars - APT.
7. Baby Lores - La Mujer del Pelotero
8. BM y Luck Ra - La Morocha
9. Lola Indigo - LA REINA
10. Katy Perry - Roar
11. Los Rodriguez - Hace Calor
12. Paulina Rubio - Y Yo Sigo Aqui
13. Chimbala - Feliz
14. Macaco - Ojala no te hubiera conocido nunca
15. Zapato Veloz - Tractor Amarillo

---

## Cartón 141

1. ROSALÍA - DESPECHÁ
2. Isabel Aaiún - El Himno de Mi Peña
3. Cali Flow Latino - Ras Tas Tas
4. Rauw Alejandro - Todo de Ti
5. Santa Fe - Esto Es Pa Ti
6. Chocolate - Mayonesa
7. El Hormiguero - Marron
8. Daddy Yankee - Limbo
9. Proyecto Uno - El Tiburón
10. Daddy Yankee Feat. Omega - Estrellita De Madrugada
11. Camilo - Vida de Rico
12. ACDC - T.N.T
13. Pereza - Princesas
14. Mambo No. 5 (A Little Bit of...)
15. KAROL G - Si Antes Te Hubiera Conocido

---

## Cartón 142

1. SHAKIRA - BZRP Music Sessions #53
2. Sebastián Yatra - Tacones Rojos
3. Flying free - Pont Aeri
4. Los Manolos - All my Lovin
5. David Civera - Que La Detengan
6. Blues Brothers - Everybody Needs Somebody To Love
7. Climax - Mesa Que Mas Aplauda
8. Carlinhos Brown and DJ Dero - Maria caipirinha
9. Radio Futura - Escuela de Calor
10. SBS - Sigue Al Lider (Follow The Leader)
11. El chaval de la peca - Abanibi
12. Alaska y Dinarama - A Quién Le Importa
13. Aitana - LAS BABYS
14. Gasolina - Daddy Yankee
15. Nino Bravo - Libre

---

## Cartón 143

1. El canto del loco - Zapatillas
2. Santa Fe - Esto Es Pa Ti
3. El chaval de la peca - Abanibi
4. El Barrio - Quiéreme
5. Camela - Cuando zarpa el amor
6. Los Rodriguez - Hace Calor
7. Coyote Dax - No Rompas Mi Corazón
8. María Isabel - Antes muerta que sencilla
9. DON OMAR - DILE, CUENTALE (BATUCADA)
10. Sebastián Yatra - Tacones Rojos
11. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
12. Raphael - Mi Gran noche
13. Pitbull - El Taxi
14. Los chicanos del sur - Beso a beso
15. La Oreja de Van Gogh - Rosas

---

## Cartón 144

1. Georgie Dann - La Barbacoa
2. Zapato Veloz - Tractor Amarillo
3. King Africa - Bomba
4. Katy Perry - Roar
5. Juan Magán - Bailando por Ahi
6. Bad Bunny - Yo Perreo Sola
7. David Bisbal y Aitana - Si Tú La Quieres
8. Hector y Tito ft. Don Omar - Baila morena
9. La Fiesta - La canción del velero
10. Marta, Sebas, Guille y los demás (Amaral)
11. King Africa - Paquito el chocolatero
12. Pereza - Princesas
13. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
14. Camela - Cuando zarpa el amor
15. Rauw Alejandro - Todo de Ti

---

## Cartón 145

1. ACDC - T.N.T
2. Proyecto Uno - El Tiburón
3. Daddy Yankee - Limbo
4. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
5. Los Delincuentes - Nube de Pegatina
6. Los Manolos - All my Lovin
7. David Civera - Que La Detengan
8. The Refrescos - Aquí No Hay Playa
9. José Luis Perales - Un Velero Llamado Libertad
10. Cue Dj - El Baile Del Serrucho
11. Mambo No. 5 (A Little Bit of...)
12. Macaco - Ojala no te hubiera conocido nunca
13. Myke Towers - LA FALDA
14. Hector y Tito ft. Don Omar - Baila morena
15. Bad Bunny - Yo Perreo Sola

---

## Cartón 146

1. José Luis Perales - Un Velero Llamado Libertad
2. Eivissa - Oh La La La
3. Vicco - Nochentera
4. Tequila - Salta
5. Carlinhos Brown and DJ Dero - Maria caipirinha
6. El Simbolo - Levantando Las Manos
7. La Oreja de Van Gogh - Rosas
8. Las Ketchup - Aserejé
9. Pitbull - El Taxi
10. Baby Lores - La Mujer del Pelotero
11. ROSALÍA, J Balvin - Con Altura
12. La Hungara - Achilipu
13. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
14. Isabel Aaiún - El Himno de Mi Peña
15. Climax - Mesa Que Mas Aplauda

---

## Cartón 147

1. ROSALÍA - DESPECHÁ
2. Lola Indigo - LA REINA
3. Juan Magán - Bailando por Ahi
4. Jarabe de Palo - Eso que tú me das
5. Seguridad social - Chiquilla
6. King Africa - Bomba
7. El canto del loco - Zapatillas
8. ACDC - T.N.T
9. El Barrio - Quiéreme
10. SBS - Sigue Al Lider (Follow The Leader)
11. KAROL G - Si Antes Te Hubiera Conocido
12. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
13. Joaquin Sabina - Y Nos Dieron las Diez (Video)
14. Cali Flow Latino - Ras Tas Tas
15. Alaska y Dinarama - A Quién Le Importa

---

## Cartón 148

1. Flying free - Pont Aeri
2. Nino Bravo - Libre
3. Gente De Zona - La Gozadera
4. Melendi - Caminando por la Vida
5. King Africa - Paquito el chocolatero
6. ROSÉ y Bruno Mars - APT.
7. Paulina Rubio - Y Yo Sigo Aqui
8. Katy Perry - Roar
9. El canto del loco - Zapatillas
10. IZAL - La mujer de verde
11. The Refrescos - Aquí No Hay Playa
12. Daddy Yankee - Limbo
13. La Fiesta - La canción del velero
14. La Pegatina - MariCarmen
15. CNCO - Reggaetón Lento (Bailemos)

---

## Cartón 149

1. El chombo - El gato volador
2. Los Delincuentes - Nube de Pegatina
3. David Bisbal y Aitana - Si Tú La Quieres
4. DON OMAR - DILE, CUENTALE (BATUCADA)
5. Las Ketchup - Aserejé
6. Eivissa - Oh La La La
7. Coyote Dax - No Rompas Mi Corazón
8. La Fiesta - La canción del velero
9. LOS LUNNIS - HASTA MAÑANA
10. Jarabe de Palo - Eso que tú me das
11. ROSALÍA, J Balvin - Con Altura
12. Los chicanos del sur - Beso a beso
13. Hector y Tito ft. Don Omar - Baila morena
14. El Consorcio - El chacachá del tren
15. Lola Indigo - LA REINA

---

## Cartón 150

1. ROSALÍA - DESPECHÁ
2. Mambo No. 5 (A Little Bit of...)
3. El Simbolo - Levantando Las Manos
4. KAROL G - Si Antes Te Hubiera Conocido
5. Don Omar - Danza Kuduro
6. Camilo - Vida de Rico
7. Myke Towers - LA FALDA
8. Isabel Aaiún - El Himno de Mi Peña
9. Raphael - Mi Gran noche
10. El chaval de la peca - Abanibi
11. El Hormiguero - Marron
12. Dos Gardenias - Dos Gardenias
13. Camela - Cuando zarpa el amor
14. Climax - Mesa Que Mas Aplauda
15. Coyote Dax - No Rompas Mi Corazón

---

## Cartón 151

1. Los Del Río - Macarena
2. Santa Fe - Esto Es Pa Ti
3. Rauw Alejandro - Todo de Ti
4. Radio Futura - Escuela de Calor
5. Aitana - LAS BABYS
6. CNCO - Reggaetón Lento (Bailemos)
7. Estopa - La Raja De Tu Falda
8. Mano Negra - Mala Vida
9. Los chicanos del sur - Beso a beso
10. El chaval de la peca - Abanibi
11. Baby Lores - La Mujer del Pelotero
12. El canto del loco - Zapatillas
13. Los Rodriguez - Hace Calor
14. Daddy Yankee Feat. Omega - Estrellita De Madrugada
15. El Consorcio - El chacachá del tren

---

## Cartón 152

1. Aitana - LAS BABYS
2. Carlinhos Brown and DJ Dero - Maria caipirinha
3. Macaco - Ojala no te hubiera conocido nunca
4. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
5. ROSALÍA, J Balvin - Con Altura
6. Sebastián Yatra - Tacones Rojos
7. Daddy Yankee Feat. Omega - Estrellita De Madrugada
8. Los Manolos - All my Lovin
9. Cali Flow Latino - Ras Tas Tas
10. BM y Luck Ra - La Morocha
11. La Pegatina - MariCarmen
12. David Bisbal y Aitana - Si Tú La Quieres
13. Chocolate - Mayonesa
14. LOS LUNNIS - HASTA MAÑANA
15. Hector y Tito ft. Don Omar - Baila morena

---

## Cartón 153

1. Juan Magán - Bailando por Ahi
2. Zapato Veloz - Tractor Amarillo
3. Bad Bunny - Yo Perreo Sola
4. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
5. KAROL G - Si Antes Te Hubiera Conocido
6. David Civera - Que La Detengan
7. José Luis Perales - Un Velero Llamado Libertad
8. Chimbala - Feliz
9. Marta, Sebas, Guille y los demás (Amaral)
10. Flying free - Pont Aeri
11. King Africa - Paquito el chocolatero
12. Santa Fe - Esto Es Pa Ti
13. SHAKIRA - BZRP Music Sessions #53
14. ROSÉ y Bruno Mars - APT.
15. Vicco - Nochentera

---

## Cartón 154

1. Estopa - La Raja De Tu Falda
2. El Barrio - Quiéreme
3. Tequila - Salta
4. Proyecto Uno - El Tiburón
5. La Pegatina - MariCarmen
6. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
7. David Civera - Que La Detengan
8. Katy Perry - Roar
9. Cue Dj - El Baile Del Serrucho
10. Camela - Cuando zarpa el amor
11. Pereza - Princesas
12. Joaquin Sabina - Y Nos Dieron las Diez (Video)
13. El chombo - El gato volador
14. King Africa - Bomba
15. Alaska y Dinarama - A Quién Le Importa

---

## Cartón 155

1. La Fiesta - La canción del velero
2. Tequila - Salta
3. Raphael - Mi Gran noche
4. Climax - Mesa Que Mas Aplauda
5. Gasolina - Daddy Yankee
6. Paulina Rubio - Y Yo Sigo Aqui
7. The Refrescos - Aquí No Hay Playa
8. Radio Futura - Escuela de Calor
9. José Luis Perales - Un Velero Llamado Libertad
10. SHAKIRA - BZRP Music Sessions #53
11. La Hungara - Achilipu
12. Carlinhos Brown and DJ Dero - Maria caipirinha
13. María Isabel - Antes muerta que sencilla
14. Blues Brothers - Everybody Needs Somebody To Love
15. Flying free - Pont Aeri

---

## Cartón 156

1. Gasolina - Daddy Yankee
2. Don Omar - Danza Kuduro
3. Eivissa - Oh La La La
4. King Africa - Bomba
5. Cali Flow Latino - Ras Tas Tas
6. BM y Luck Ra - La Morocha
7. La Hungara - Achilipu
8. Joaquin Sabina - Y Nos Dieron las Diez (Video)
9. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
10. Melendi - Caminando por la Vida
11. ROSALÍA - DESPECHÁ
12. Pereza - Princesas
13. Pitbull - El Taxi
14. Gente De Zona - La Gozadera
15. Los Rodriguez - Hace Calor

---

## Cartón 157

1. IZAL - La mujer de verde
2. Eivissa - Oh La La La
3. SBS - Sigue Al Lider (Follow The Leader)
4. Los Del Río - Macarena
5. Myke Towers - LA FALDA
6. Nino Bravo - Libre
7. Zapato Veloz - Tractor Amarillo
8. King Africa - Paquito el chocolatero
9. Los chicanos del sur - Beso a beso
10. Paulina Rubio - Y Yo Sigo Aqui
11. Georgie Dann - La Barbacoa
12. King Africa - Bomba
13. La Oreja de Van Gogh - Rosas
14. ACDC - T.N.T
15. ROSÉ y Bruno Mars - APT.

---

## Cartón 158

1. Las Ketchup - Aserejé
2. Mano Negra - Mala Vida
3. SHAKIRA - BZRP Music Sessions #53
4. Jarabe de Palo - Eso que tú me das
5. CNCO - Reggaetón Lento (Bailemos)
6. El Hormiguero - Marron
7. Camela - Cuando zarpa el amor
8. Chimbala - Feliz
9. IZAL - La mujer de verde
10. Pitbull - El Taxi
11. Seguridad social - Chiquilla
12. Chocolate - Mayonesa
13. Daddy Yankee Feat. Omega - Estrellita De Madrugada
14. Mambo No. 5 (A Little Bit of...)
15. Los Rodriguez - Hace Calor

---

## Cartón 159

1. Juan Magán - Bailando por Ahi
2. Macaco - Ojala no te hubiera conocido nunca
3. Coyote Dax - No Rompas Mi Corazón
4. Cue Dj - El Baile Del Serrucho
5. The Refrescos - Aquí No Hay Playa
6. Dos Gardenias - Dos Gardenias
7. Camilo - Vida de Rico
8. El Hormiguero - Marron
9. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
10. La Pegatina - MariCarmen
11. El Barrio - Quiéreme
12. Aitana - LAS BABYS
13. Marta, Sebas, Guille y los demás (Amaral)
14. Lola Indigo - LA REINA
15. Gasolina - Daddy Yankee

---

## Cartón 160

1. BM y Luck Ra - La Morocha
2. Santa Fe - Esto Es Pa Ti
3. Hector y Tito ft. Don Omar - Baila morena
4. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
5. Los Manolos - All my Lovin
6. Chimbala - Feliz
7. Camilo - Vida de Rico
8. Raphael - Mi Gran noche
9. Georgie Dann - La Barbacoa
10. Juan Magán - Bailando por Ahi
11. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
12. Lola Indigo - LA REINA
13. Las Ketchup - Aserejé
14. María Isabel - Antes muerta que sencilla
15. Aitana - LAS BABYS

---

## Cartón 161

1. Dos Gardenias - Dos Gardenias
2. Camilo - Vida de Rico
3. Los Del Río - Macarena
4. Mano Negra - Mala Vida
5. The Refrescos - Aquí No Hay Playa
6. El Consorcio - El chacachá del tren
7. Don Omar - Danza Kuduro
8. David Bisbal y Aitana - Si Tú La Quieres
9. Isabel Aaiún - El Himno de Mi Peña
10. Flying free - Pont Aeri
11. Los chicanos del sur - Beso a beso
12. Daddy Yankee - Limbo
13. Mambo No. 5 (A Little Bit of...)
14. Gente De Zona - La Gozadera
15. ROSALÍA, J Balvin - Con Altura

---

## Cartón 162

1. Vicco - Nochentera
2. Blues Brothers - Everybody Needs Somebody To Love
3. Estopa - La Raja De Tu Falda
4. Eivissa - Oh La La La
5. Seguridad social - Chiquilla
6. Baby Lores - La Mujer del Pelotero
7. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
8. José Luis Perales - Un Velero Llamado Libertad
9. Myke Towers - LA FALDA
10. KAROL G - Si Antes Te Hubiera Conocido
11. Las Ketchup - Aserejé
12. LOS LUNNIS - HASTA MAÑANA
13. El Barrio - Quiéreme
14. David Bisbal y Aitana - Si Tú La Quieres
15. Climax - Mesa Que Mas Aplauda

---

## Cartón 163

1. Vicco - Nochentera
2. Los Delincuentes - Nube de Pegatina
3. Joaquin Sabina - Y Nos Dieron las Diez (Video)
4. Bad Bunny - Yo Perreo Sola
5. La Hungara - Achilipu
6. El Simbolo - Levantando Las Manos
7. Alaska y Dinarama - A Quién Le Importa
8. Gente De Zona - La Gozadera
9. Rauw Alejandro - Todo de Ti
10. IZAL - La mujer de verde
11. El chombo - El gato volador
12. DON OMAR - DILE, CUENTALE (BATUCADA)
13. La Oreja de Van Gogh - Rosas
14. Mano Negra - Mala Vida
15. King Africa - Paquito el chocolatero

---

## Cartón 164

1. Joaquin Sabina - Y Nos Dieron las Diez (Video)
2. Dos Gardenias - Dos Gardenias
3. Gasolina - Daddy Yankee
4. Baby Lores - La Mujer del Pelotero
5. Pereza - Princesas
6. Bad Bunny - Yo Perreo Sola
7. La Pegatina - MariCarmen
8. Los Delincuentes - Nube de Pegatina
9. Radio Futura - Escuela de Calor
10. Los Del Río - Macarena
11. Carlinhos Brown and DJ Dero - Maria caipirinha
12. Nino Bravo - Libre
13. LOS LUNNIS - HASTA MAÑANA
14. ACDC - T.N.T
15. Chocolate - Mayonesa

---

## Cartón 165

1. ROSALÍA, J Balvin - Con Altura
2. Chimbala - Feliz
3. Hector y Tito ft. Don Omar - Baila morena
4. David Civera - Que La Detengan
5. The Refrescos - Aquí No Hay Playa
6. SBS - Sigue Al Lider (Follow The Leader)
7. King Africa - Paquito el chocolatero
8. BM y Luck Ra - La Morocha
9. El Simbolo - Levantando Las Manos
10. Proyecto Uno - El Tiburón
11. SHAKIRA - BZRP Music Sessions #53
12. Alaska y Dinarama - A Quién Le Importa
13. Sebastián Yatra - Tacones Rojos
14. Climax - Mesa Que Mas Aplauda
15. Camela - Cuando zarpa el amor

---

## Cartón 166

1. Zapato Veloz - Tractor Amarillo
2. Marta, Sebas, Guille y los demás (Amaral)
3. Sebastián Yatra - Tacones Rojos
4. Rauw Alejandro - Todo de Ti
5. Isabel Aaiún - El Himno de Mi Peña
6. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
7. Daddy Yankee - Limbo
8. Chocolate - Mayonesa
9. José Luis Perales - Un Velero Llamado Libertad
10. Los Manolos - All my Lovin
11. El canto del loco - Zapatillas
12. ROSÉ y Bruno Mars - APT.
13. Katy Perry - Roar
14. Nino Bravo - Libre
15. Cue Dj - El Baile Del Serrucho

---

## Cartón 167

1. Melendi - Caminando por la Vida
2. Baby Lores - La Mujer del Pelotero
3. Los Delincuentes - Nube de Pegatina
4. La Pegatina - MariCarmen
5. Estopa - La Raja De Tu Falda
6. Cali Flow Latino - Ras Tas Tas
7. Pitbull - El Taxi
8. Camela - Cuando zarpa el amor
9. LOS LUNNIS - HASTA MAÑANA
10. Hector y Tito ft. Don Omar - Baila morena
11. Proyecto Uno - El Tiburón
12. SBS - Sigue Al Lider (Follow The Leader)
13. CNCO - Reggaetón Lento (Bailemos)
14. El chaval de la peca - Abanibi
15. Juan Magán - Bailando por Ahi

---

## Cartón 168

1. Radio Futura - Escuela de Calor
2. Paulina Rubio - Y Yo Sigo Aqui
3. David Bisbal y Aitana - Si Tú La Quieres
4. Don Omar - Danza Kuduro
5. Myke Towers - LA FALDA
6. Los Delincuentes - Nube de Pegatina
7. ACDC - T.N.T
8. Eivissa - Oh La La La
9. Seguridad social - Chiquilla
10. Lola Indigo - LA REINA
11. ROSÉ y Bruno Mars - APT.
12. Daddy Yankee Feat. Omega - Estrellita De Madrugada
13. Estopa - La Raja De Tu Falda
14. El Hormiguero - Marron
15. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom

---

## Cartón 169

1. DON OMAR - DILE, CUENTALE (BATUCADA)
2. Blues Brothers - Everybody Needs Somebody To Love
3. Mambo No. 5 (A Little Bit of...)
4. El chombo - El gato volador
5. Myke Towers - LA FALDA
6. El Barrio - Quiéreme
7. Tequila - Salta
8. Rauw Alejandro - Todo de Ti
9. Seguridad social - Chiquilla
10. Camilo - Vida de Rico
11. El Consorcio - El chacachá del tren
12. Jarabe de Palo - Eso que tú me das
13. Cue Dj - El Baile Del Serrucho
14. Cali Flow Latino - Ras Tas Tas
15. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom

---

## Cartón 170

1. Los chicanos del sur - Beso a beso
2. BM y Luck Ra - La Morocha
3. King Africa - Bomba
4. Bad Bunny - Yo Perreo Sola
5. La Oreja de Van Gogh - Rosas
6. El canto del loco - Zapatillas
7. ROSALÍA - DESPECHÁ
8. Blues Brothers - Everybody Needs Somebody To Love
9. Paulina Rubio - Y Yo Sigo Aqui
10. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
11. SHAKIRA - BZRP Music Sessions #53
12. Coyote Dax - No Rompas Mi Corazón
13. Camilo - Vida de Rico
14. Georgie Dann - La Barbacoa
15. Daddy Yankee Feat. Omega - Estrellita De Madrugada

---

## Cartón 171

1. Radio Futura - Escuela de Calor
2. Katy Perry - Roar
3. Tequila - Salta
4. Juan Magán - Bailando por Ahi
5. Santa Fe - Esto Es Pa Ti
6. El chaval de la peca - Abanibi
7. El Simbolo - Levantando Las Manos
8. ROSALÍA - DESPECHÁ
9. Pereza - Princesas
10. El Consorcio - El chacachá del tren
11. Jarabe de Palo - Eso que tú me das
12. Gente De Zona - La Gozadera
13. Melendi - Caminando por la Vida
14. CNCO - Reggaetón Lento (Bailemos)
15. Vicco - Nochentera

---

## Cartón 172

1. Aitana - LAS BABYS
2. Climax - Mesa Que Mas Aplauda
3. Chimbala - Feliz
4. Macaco - Ojala no te hubiera conocido nunca
5. Zapato Veloz - Tractor Amarillo
6. Rauw Alejandro - Todo de Ti
7. Flying free - Pont Aeri
8. IZAL - La mujer de verde
9. Baby Lores - La Mujer del Pelotero
10. Chocolate - Mayonesa
11. Gente De Zona - La Gozadera
12. Las Ketchup - Aserejé
13. La Fiesta - La canción del velero
14. Los Del Río - Macarena
15. Raphael - Mi Gran noche

---

## Cartón 173

1. Sebastián Yatra - Tacones Rojos
2. Vicco - Nochentera
3. Los Manolos - All my Lovin
4. Macaco - Ojala no te hubiera conocido nunca
5. Joaquin Sabina - Y Nos Dieron las Diez (Video)
6. Raphael - Mi Gran noche
7. Alaska y Dinarama - A Quién Le Importa
8. Nino Bravo - Libre
9. SHAKIRA - BZRP Music Sessions #53
10. Marta, Sebas, Guille y los demás (Amaral)
11. El Hormiguero - Marron
12. El chombo - El gato volador
13. Carlinhos Brown and DJ Dero - Maria caipirinha
14. Los Rodriguez - Hace Calor
15. ROSALÍA, J Balvin - Con Altura

---

## Cartón 174

1. Dos Gardenias - Dos Gardenias
2. Los Rodriguez - Hace Calor
3. Santa Fe - Esto Es Pa Ti
4. David Bisbal y Aitana - Si Tú La Quieres
5. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
6. Los Manolos - All my Lovin
7. Melendi - Caminando por la Vida
8. King Africa - Paquito el chocolatero
9. Hector y Tito ft. Don Omar - Baila morena
10. LOS LUNNIS - HASTA MAÑANA
11. CNCO - Reggaetón Lento (Bailemos)
12. María Isabel - Antes muerta que sencilla
13. Aitana - LAS BABYS
14. DON OMAR - DILE, CUENTALE (BATUCADA)
15. Camela - Cuando zarpa el amor

---

## Cartón 175

1. El canto del loco - Zapatillas
2. Los Del Río - Macarena
3. Cali Flow Latino - Ras Tas Tas
4. Estopa - La Raja De Tu Falda
5. Coyote Dax - No Rompas Mi Corazón
6. Alaska y Dinarama - A Quién Le Importa
7. Georgie Dann - La Barbacoa
8. Las Ketchup - Aserejé
9. Lola Indigo - LA REINA
10. Pitbull - El Taxi
11. Raphael - Mi Gran noche
12. King Africa - Paquito el chocolatero
13. La Fiesta - La canción del velero
14. SBS - Sigue Al Lider (Follow The Leader)
15. María Isabel - Antes muerta que sencilla

---

## Cartón 176

1. El chaval de la peca - Abanibi
2. KAROL G - Si Antes Te Hubiera Conocido
3. Cue Dj - El Baile Del Serrucho
4. Jarabe de Palo - Eso que tú me das
5. Paulina Rubio - Y Yo Sigo Aqui
6. Don Omar - Danza Kuduro
7. La Hungara - Achilipu
8. Coyote Dax - No Rompas Mi Corazón
9. Pereza - Princesas
10. Myke Towers - LA FALDA
11. ROSALÍA - DESPECHÁ
12. ACDC - T.N.T
13. Mambo No. 5 (A Little Bit of...)
14. Mano Negra - Mala Vida
15. Dos Gardenias - Dos Gardenias

---

## Cartón 177

1. David Civera - Que La Detengan
2. El chombo - El gato volador
3. Gasolina - Daddy Yankee
4. Juan Magán - Bailando por Ahi
5. ROSALÍA, J Balvin - Con Altura
6. ROSÉ y Bruno Mars - APT.
7. IZAL - La mujer de verde
8. Daddy Yankee - Limbo
9. Myke Towers - LA FALDA
10. Alaska y Dinarama - A Quién Le Importa
11. Los chicanos del sur - Beso a beso
12. Isabel Aaiún - El Himno de Mi Peña
13. Georgie Dann - La Barbacoa
14. El Simbolo - Levantando Las Manos
15. Coyote Dax - No Rompas Mi Corazón

---

## Cartón 178

1. Los Rodriguez - Hace Calor
2. La Oreja de Van Gogh - Rosas
3. Proyecto Uno - El Tiburón
4. El Barrio - Quiéreme
5. José Luis Perales - Un Velero Llamado Libertad
6. Mano Negra - Mala Vida
7. Bad Bunny - Yo Perreo Sola
8. Dos Gardenias - Dos Gardenias
9. CNCO - Reggaetón Lento (Bailemos)
10. Carlinhos Brown and DJ Dero - Maria caipirinha
11. El Consorcio - El chacachá del tren
12. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
13. Radio Futura - Escuela de Calor
14. La Hungara - Achilipu
15. Gasolina - Daddy Yankee

---

## Cartón 179

1. El Consorcio - El chacachá del tren
2. KAROL G - Si Antes Te Hubiera Conocido
3. David Bisbal y Aitana - Si Tú La Quieres
4. Lola Indigo - LA REINA
5. BM y Luck Ra - La Morocha
6. Sebastián Yatra - Tacones Rojos
7. María Isabel - Antes muerta que sencilla
8. Nino Bravo - Libre
9. Pitbull - El Taxi
10. Eivissa - Oh La La La
11. Radio Futura - Escuela de Calor
12. Santa Fe - Esto Es Pa Ti
13. Mano Negra - Mala Vida
14. King Africa - Bomba
15. Katy Perry - Roar

---

## Cartón 180

1. Coyote Dax - No Rompas Mi Corazón
2. Seguridad social - Chiquilla
3. Daddy Yankee - Limbo
4. Georgie Dann - La Barbacoa
5. Daddy Yankee Feat. Omega - Estrellita De Madrugada
6. La Oreja de Van Gogh - Rosas
7. SBS - Sigue Al Lider (Follow The Leader)
8. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
9. Vicco - Nochentera
10. Chocolate - Mayonesa
11. ROSÉ y Bruno Mars - APT.
12. Blues Brothers - Everybody Needs Somebody To Love
13. Mambo No. 5 (A Little Bit of...)
14. Proyecto Uno - El Tiburón
15. SHAKIRA - BZRP Music Sessions #53

---

## Cartón 181

1. Sebastián Yatra - Tacones Rojos
2. Zapato Veloz - Tractor Amarillo
3. Don Omar - Danza Kuduro
4. Isabel Aaiún - El Himno de Mi Peña
5. Camela - Cuando zarpa el amor
6. The Refrescos - Aquí No Hay Playa
7. El chaval de la peca - Abanibi
8. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
9. Melendi - Caminando por la Vida
10. David Bisbal y Aitana - Si Tú La Quieres
11. Rauw Alejandro - Todo de Ti
12. Marta, Sebas, Guille y los demás (Amaral)
13. Cue Dj - El Baile Del Serrucho
14. El Simbolo - Levantando Las Manos
15. Tequila - Salta

---

## Cartón 182

1. King Africa - Bomba
2. La Hungara - Achilipu
3. Daddy Yankee - Limbo
4. El chombo - El gato volador
5. El Hormiguero - Marron
6. Proyecto Uno - El Tiburón
7. Flying free - Pont Aeri
8. David Civera - Que La Detengan
9. Climax - Mesa Que Mas Aplauda
10. Baby Lores - La Mujer del Pelotero
11. Jarabe de Palo - Eso que tú me das
12. El canto del loco - Zapatillas
13. Los chicanos del sur - Beso a beso
14. Juan Magán - Bailando por Ahi
15. Katy Perry - Roar

---

## Cartón 183

1. Macaco - Ojala no te hubiera conocido nunca
2. Melendi - Caminando por la Vida
3. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
4. Chimbala - Feliz
5. Pereza - Princesas
6. La Fiesta - La canción del velero
7. Aitana - LAS BABYS
8. Raphael - Mi Gran noche
9. Blues Brothers - Everybody Needs Somebody To Love
10. Cue Dj - El Baile Del Serrucho
11. Santa Fe - Esto Es Pa Ti
12. El Hormiguero - Marron
13. La Pegatina - MariCarmen
14. Flying free - Pont Aeri
15. Carlinhos Brown and DJ Dero - Maria caipirinha

---

## Cartón 184

1. Gasolina - Daddy Yankee
2. ROSALÍA, J Balvin - Con Altura
3. Los Delincuentes - Nube de Pegatina
4. Chocolate - Mayonesa
5. Nino Bravo - Libre
6. Los Del Río - Macarena
7. Paulina Rubio - Y Yo Sigo Aqui
8. Joaquin Sabina - Y Nos Dieron las Diez (Video)
9. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
10. La Fiesta - La canción del velero
11. Blues Brothers - Everybody Needs Somebody To Love
12. Estopa - La Raja De Tu Falda
13. The Refrescos - Aquí No Hay Playa
14. Eivissa - Oh La La La
15. El Barrio - Quiéreme

---

## Cartón 185

1. Los Delincuentes - Nube de Pegatina
2. ROSALÍA - DESPECHÁ
3. Los Rodriguez - Hace Calor
4. Joaquin Sabina - Y Nos Dieron las Diez (Video)
5. José Luis Perales - Un Velero Llamado Libertad
6. Chimbala - Feliz
7. Flying free - Pont Aeri
8. Los Manolos - All my Lovin
9. Zapato Veloz - Tractor Amarillo
10. Camilo - Vida de Rico
11. KAROL G - Si Antes Te Hubiera Conocido
12. Paulina Rubio - Y Yo Sigo Aqui
13. La Oreja de Van Gogh - Rosas
14. El canto del loco - Zapatillas
15. Climax - Mesa Que Mas Aplauda

---

## Cartón 186

1. Los Del Río - Macarena
2. DON OMAR - DILE, CUENTALE (BATUCADA)
3. Lola Indigo - LA REINA
4. Bad Bunny - Yo Perreo Sola
5. Sebastián Yatra - Tacones Rojos
6. BM y Luck Ra - La Morocha
7. Mano Negra - Mala Vida
8. Cue Dj - El Baile Del Serrucho
9. María Isabel - Antes muerta que sencilla
10. ACDC - T.N.T
11. ROSÉ y Bruno Mars - APT.
12. José Luis Perales - Un Velero Llamado Libertad
13. Pitbull - El Taxi
14. LOS LUNNIS - HASTA MAÑANA
15. Cali Flow Latino - Ras Tas Tas

---

## Cartón 187

1. Cali Flow Latino - Ras Tas Tas
2. Macaco - Ojala no te hubiera conocido nunca
3. Juan Magán - Bailando por Ahi
4. Camilo - Vida de Rico
5. David Civera - Que La Detengan
6. Dos Gardenias - Dos Gardenias
7. El Hormiguero - Marron
8. ROSALÍA - DESPECHÁ
9. SBS - Sigue Al Lider (Follow The Leader)
10. BM y Luck Ra - La Morocha
11. Marta, Sebas, Guille y los demás (Amaral)
12. Nino Bravo - Libre
13. Los Rodriguez - Hace Calor
14. Isabel Aaiún - El Himno de Mi Peña
15. Gente De Zona - La Gozadera

---

## Cartón 188

1. La Fiesta - La canción del velero
2. Macaco - Ojala no te hubiera conocido nunca
3. Radio Futura - Escuela de Calor
4. El chaval de la peca - Abanibi
5. La Hungara - Achilipu
6. Santa Fe - Esto Es Pa Ti
7. El Consorcio - El chacachá del tren
8. LOS LUNNIS - HASTA MAÑANA
9. Tequila - Salta
10. Rauw Alejandro - Todo de Ti
11. DON OMAR - DILE, CUENTALE (BATUCADA)
12. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
13. Hector y Tito ft. Don Omar - Baila morena
14. David Civera - Que La Detengan
15. Eivissa - Oh La La La

---

## Cartón 189

1. Camela - Cuando zarpa el amor
2. Mano Negra - Mala Vida
3. Daddy Yankee - Limbo
4. Myke Towers - LA FALDA
5. La Pegatina - MariCarmen
6. Daddy Yankee Feat. Omega - Estrellita De Madrugada
7. Seguridad social - Chiquilla
8. Vicco - Nochentera
9. SBS - Sigue Al Lider (Follow The Leader)
10. Coyote Dax - No Rompas Mi Corazón
11. Don Omar - Danza Kuduro
12. Dos Gardenias - Dos Gardenias
13. El chombo - El gato volador
14. Alaska y Dinarama - A Quién Le Importa
15. Bad Bunny - Yo Perreo Sola

---

## Cartón 190

1. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
2. Chimbala - Feliz
3. Pitbull - El Taxi
4. Zapato Veloz - Tractor Amarillo
5. Cali Flow Latino - Ras Tas Tas
6. KAROL G - Si Antes Te Hubiera Conocido
7. Raphael - Mi Gran noche
8. Estopa - La Raja De Tu Falda
9. Climax - Mesa Que Mas Aplauda
10. Aitana - LAS BABYS
11. Joaquin Sabina - Y Nos Dieron las Diez (Video)
12. King Africa - Bomba
13. King Africa - Paquito el chocolatero
14. Hector y Tito ft. Don Omar - Baila morena
15. ROSALÍA, J Balvin - Con Altura

---

## Cartón 191

1. CNCO - Reggaetón Lento (Bailemos)
2. La Oreja de Van Gogh - Rosas
3. SHAKIRA - BZRP Music Sessions #53
4. Estopa - La Raja De Tu Falda
5. El Consorcio - El chacachá del tren
6. Eivissa - Oh La La La
7. Baby Lores - La Mujer del Pelotero
8. Jarabe de Palo - Eso que tú me das
9. Vicco - Nochentera
10. El Barrio - Quiéreme
11. IZAL - La mujer de verde
12. María Isabel - Antes muerta que sencilla
13. Las Ketchup - Aserejé
14. Los chicanos del sur - Beso a beso
15. Seguridad social - Chiquilla

---

## Cartón 192

1. KAROL G - Si Antes Te Hubiera Conocido
2. Las Ketchup - Aserejé
3. La Pegatina - MariCarmen
4. Daddy Yankee Feat. Omega - Estrellita De Madrugada
5. Juan Magán - Bailando por Ahi
6. El Barrio - Quiéreme
7. Chimbala - Feliz
8. Los Delincuentes - Nube de Pegatina
9. Tequila - Salta
10. Lola Indigo - LA REINA
11. Carlinhos Brown and DJ Dero - Maria caipirinha
12. Chocolate - Mayonesa
13. La Oreja de Van Gogh - Rosas
14. Seguridad social - Chiquilla
15. Proyecto Uno - El Tiburón

---

## Cartón 193

1. IZAL - La mujer de verde
2. Katy Perry - Roar
3. Marta, Sebas, Guille y los demás (Amaral)
4. Nino Bravo - Libre
5. SHAKIRA - BZRP Music Sessions #53
6. Chimbala - Feliz
7. Los Delincuentes - Nube de Pegatina
8. Don Omar - Danza Kuduro
9. Isabel Aaiún - El Himno de Mi Peña
10. Mambo No. 5 (A Little Bit of...)
11. ACDC - T.N.T
12. LOS LUNNIS - HASTA MAÑANA
13. Myke Towers - LA FALDA
14. Radio Futura - Escuela de Calor
15. Proyecto Uno - El Tiburón

---

## Cartón 194

1. Las Ketchup - Aserejé
2. José Luis Perales - Un Velero Llamado Libertad
3. King Africa - Bomba
4. Baby Lores - La Mujer del Pelotero
5. Climax - Mesa Que Mas Aplauda
6. Mano Negra - Mala Vida
7. Georgie Dann - La Barbacoa
8. Katy Perry - Roar
9. ACDC - T.N.T
10. SBS - Sigue Al Lider (Follow The Leader)
11. Pereza - Princesas
12. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
13. Melendi - Caminando por la Vida
14. Gente De Zona - La Gozadera
15. Don Omar - Danza Kuduro

---

## Cartón 195

1. Los Manolos - All my Lovin
2. Flying free - Pont Aeri
3. José Luis Perales - Un Velero Llamado Libertad
4. Daddy Yankee Feat. Omega - Estrellita De Madrugada
5. El canto del loco - Zapatillas
6. Melendi - Caminando por la Vida
7. Gasolina - Daddy Yankee
8. Santa Fe - Esto Es Pa Ti
9. Daddy Yankee - Limbo
10. IZAL - La mujer de verde
11. Hector y Tito ft. Don Omar - Baila morena
12. Don Omar - Danza Kuduro
13. Camela - Cuando zarpa el amor
14. El Simbolo - Levantando Las Manos
15. El Hormiguero - Marron

---

## Cartón 196

1. Aitana - LAS BABYS
2. Jarabe de Palo - Eso que tú me das
3. Mambo No. 5 (A Little Bit of...)
4. DON OMAR - DILE, CUENTALE (BATUCADA)
5. Alaska y Dinarama - A Quién Le Importa
6. Isabel Aaiún - El Himno de Mi Peña
7. Marta, Sebas, Guille y los demás (Amaral)
8. ROSALÍA - DESPECHÁ
9. Vicco - Nochentera
10. CNCO - Reggaetón Lento (Bailemos)
11. Lola Indigo - LA REINA
12. El chaval de la peca - Abanibi
13. Los Del Río - Macarena
14. Paulina Rubio - Y Yo Sigo Aqui
15. La Fiesta - La canción del velero

---

## Cartón 197

1. El Consorcio - El chacachá del tren
2. La Hungara - Achilipu
3. DON OMAR - DILE, CUENTALE (BATUCADA)
4. The Refrescos - Aquí No Hay Playa
5. Georgie Dann - La Barbacoa
6. Tequila - Salta
7. Cue Dj - El Baile Del Serrucho
8. La Oreja de Van Gogh - Rosas
9. Mambo No. 5 (A Little Bit of...)
10. La Pegatina - MariCarmen
11. Los Del Río - Macarena
12. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
13. María Isabel - Antes muerta que sencilla
14. El Simbolo - Levantando Las Manos
15. Blues Brothers - Everybody Needs Somebody To Love

---

## Cartón 198

1. Camilo - Vida de Rico
2. Bad Bunny - Yo Perreo Sola
3. ROSALÍA, J Balvin - Con Altura
4. The Refrescos - Aquí No Hay Playa
5. BM y Luck Ra - La Morocha
6. Pitbull - El Taxi
7. Chocolate - Mayonesa
8. Fito Y Los Fitipaldis & Extremoduro - En Ni Nuve Azul
9. Melendi - Caminando por la Vida
10. Cue Dj - El Baile Del Serrucho
11. Omega El Fuerte - Si Te Vas Que Tengo Que Hacer
12. Raphael - Mi Gran noche
13. Los chicanos del sur - Beso a beso
14. Macaco - Ojala no te hubiera conocido nunca
15. Tequila - Salta

---

## Cartón 199

1. King Africa - Paquito el chocolatero
2. SHAKIRA - BZRP Music Sessions #53
3. Estopa - La Raja De Tu Falda
4. Daddy Yankee - Limbo
5. Daddy Yankee Feat. Omega - Estrellita De Madrugada
6. David Civera - Que La Detengan
7. ROSÉ y Bruno Mars - APT.
8. Carlinhos Brown and DJ Dero - Maria caipirinha
9. Paulina Rubio - Y Yo Sigo Aqui
10. Eivissa - Oh La La La
11. Sebastián Yatra - Tacones Rojos
12. Raphael - Mi Gran noche
13. Coyote Dax - No Rompas Mi Corazón
14. Los Rodriguez - Hace Calor
15. Rauw Alejandro - Todo de Ti

---

## Cartón 200

1. 50 Cent X Bad Bunny X Rochy RD - Titi Me Pregunto Just A Little Bit Uva Bombom
2. King Africa - Paquito el chocolatero
3. Camilo - Vida de Rico
4. Eivissa - Oh La La La
5. Gente De Zona - La Gozadera
6. Seguridad social - Chiquilla
7. Camela - Cuando zarpa el amor
8. Alaska y Dinarama - A Quién Le Importa
9. El chombo - El gato volador
10. Cali Flow Latino - Ras Tas Tas
11. Zapato Veloz - Tractor Amarillo
12. Jarabe de Palo - Eso que tú me das
13. David Civera - Que La Detengan
14. Climax - Mesa Que Mas Aplauda
15. ROSALÍA - DESPECHÁ

---
